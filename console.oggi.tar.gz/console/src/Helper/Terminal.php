<?php

/**
 * Part of Omega - Console Package
 * php version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Helper;

use function array_map;
use function array_search;
use function exec;
use function implode;
use function is_array;
use function preg_match_all;

/**
 * Terminal class.
 *
 * A utility class to retrieve information about the current terminal, such as width and height.
 * Provides cross-platform support for detecting terminal dimensions on both Windows and Unix-like systems.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Helper
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version    1.0.0
 */
class Terminal
{
    /**
     * Determines whether the operating system is Windows.
     *
     * @return bool Return true if running on Windows, false otherwise.
     */
    public static function isWindows(): bool
    {
        // If PHP_OS is defined, use it - More reliable:
        if (defined('PHP_OS')) {
            return str_starts_with(strtoupper(PHP_OS), 'WIN'); // May be 'WINNT' or 'WIN32' or 'Windows'
        }

        // @codeCoverageIgnoreStart
        return '\\' === DIRECTORY_SEPARATOR; // Fallback - Less reliable (Windows 7...)
        // @codeCoverageIgnoreEnd
    }

    /**
     * Retrieves the terminal's width.
     *
     * @return int|null Return the terminal width in columns, or null if unavailable.
     */
    public function getWidth(): ?int
    {
        return $this->getDimension('width');
    }

    /**
     * Retrieves the terminal's height.
     *
     * @return int|null Return the terminal height in rows, or null if unavailable.
     */
    public function getHeight(): ?int
    {
        return $this->getDimension('height');
    }

    /**
     * Retrieves the specified terminal dimension.
     *
     * @param string $key Holds the dimension type ('width' or 'height').
     * @return int|null Return the requested dimension value, or null if unavailable.
     * @noinspection PhpUnnecessaryCurlyVarSyntaxInspection
     */
    protected function getDimension(string $key): ?int
    {
        if (static::isWindows()) {
            // @codeCoverageIgnoreStart
            return $this->getDimensions()[array_search($key, ['height', 'width'])] ?? null;
            // @codeCoverageIgnoreEnd
        }

        $type   = ['width'  => 'cols', 'height' => 'lines'][$key];
        $result = exec("tput {$type} 2>/dev/null");

        return $result === false ? null : (int) $result;
    }

    /**
     * Retrieves terminal dimensions on Windows.
     *
     * @return int[] Return an array containing height and width values, or an empty array if unavailable.
     */
    protected function getDimensions(): array
    {
        exec('mode CON', $output);

        if (!is_array($output)) {
            return [];
        }

        $output = implode("\n", $output);

        preg_match_all('/.*:\s*(\d+)/', $output, $matches);

        return array_map('intval', $matches[1] ?? []);
    }
}
