<?php

/**
 * Part of Omega - Console Package
 * php version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Helper;

use Omega\Console\Input\Option;
use Omega\Console\Input\Parameter\Parameter;

use function array_merge;
use function explode;
use function implode;
use function ltrim;
use function preg_match;
use function str_split;

/**
 * Normalizer class.
 *
 * The `Normalizer` class is a utility for processing command-line arguments and
 * values within the Omega Console framework. It handles the parsing and transformation
 * of input parameters, ensuring consistency in how arguments and options are interpreted.
 * This class is primarily intended for internal use and is not designed as part of the public
 * API.
 *
 *
 * This class is responsible for parsing arguments passed to the console, such as:
 * - Splitting combined short options (e.g., `-abc` into `-a -b -c`)
 * - Separating long options with values (e.g., `--option=value` into `--option value`)
 * - Ensuring correct handling of boolean flags and required parameters.
 *
 * * **Note:** This class is intended for internal use within the Omega Console package.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Helper
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version    1.0.0
 */
class Normalizer
{
    /**
     * Normalizes command-line arguments.
     *
     * This method processes argument strings to:
     * - Expand combined short options (`-abc` → `-a -b -c`)
     * - Separate long options from their values (`--option=value` → `--option value`)
     * - Preserve standalone arguments.
     *
     * @param array $args Holds the list of raw command-line arguments.
     * @return array Return the normalized argument list.
     * @noinspection RegExpRedundantEscape
     */
    public function normalizeArgs(array $args): array
    {
        $normalized = [];

        foreach ($args as $arg) {
            if (preg_match('/^\-\w=/', $arg)) {
                $normalized = array_merge($normalized, explode('=', $arg));
            } elseif (preg_match('/^\-\w{2,}/', $arg)) {
                $splitArg   = implode(' -', str_split(ltrim($arg, '-')));
                $normalized = array_merge($normalized, explode(' ', '-' . $splitArg));
            } elseif (preg_match('/^\-\-([^\s\=]+)\=/', $arg)) {
                $normalized = array_merge($normalized, explode('=', $arg));
            } else {
                $normalized[] = $arg;
            }
        }

        return $normalized;
    }

    /**
     * Normalizes a value based on its parameter type.
     *
     * - Boolean options toggle between true/false.
     * - Variadic parameters return an array.
     * - Required parameters return `null` if no value is provided.
     * - Applies a filter if the parameter defines one.
     *
     * @param Parameter   $parameter Holds the parameter definition.
     * @param string|null $value     Holds the raw value to be normalized.
     * @return mixed Return the processed value based on the parameter type.
     */
    public function normalizeValue(Parameter $parameter, ?string $value = null): mixed
    {
        if ($parameter instanceof Option && $parameter->isBoolean()) {
            return !$parameter->getDefault();
        }

        if ($parameter->isVariadic()) {
            return (array) $value;
        }

        if (null === $value) {
            return $parameter->isRequired() ? null : true;
        }

        return $parameter->filter($value);
    }
}
