<?php

/**
 * Part of Omega - Console Package
 * php version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Helper;

use Omega\Console\Exception\ConsoleExceptionInterface;
use Omega\Console\Input\Argument;
use Omega\Console\Input\Command;
use Omega\Console\Input\Groupable\GroupableInterface;
use Omega\Console\Input\Option;
use Omega\Console\Input\Parameter\Parameter;
use Omega\Console\Output\Writer;
use Omega\Console\Trait\InflectorTrait;
use Throwable;

use function array_map;
use function array_shift;
use function asort;
use function explode;
use function get_class;
use function gettype;
use function implode;
use function is_array;
use function is_object;
use function is_scalar;
use function key;
use function levenshtein;
use function max;
use function method_exists;
use function preg_replace;
use function preg_replace_callback;
use function realpath;
use function sprintf;
use function str_contains;
use function str_pad;
use function str_replace;
use function strlen;
use function strrpos;
use function trim;
use function uasort;
use function var_export;

use const STR_PAD_LEFT;

/**
 * OutputHelper is responsible for formatting and displaying structured output in the Omega console.
 *
 * It provides methods for:
 * - Displaying error stack traces
 * - Showing help messages for commands, options, and arguments
 * - Formatting and printing usage examples
 * - Suggesting similar commands when an invalid command is entered
 *
 * This class is primarily used internally by the Omega Console framework to enhance user experience.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Helper
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version    1.0.0
 */
class OutputHelper
{
    use InflectorTrait;

    /** @var Writer Holds the Writer instance used for formatted console output. */
    protected Writer $writer;

    /** @var int Holds the maximum width of command names, used for formatting command lists. */
    protected int $maxCmdName = 0;

    /**
     * Constructs the OutputHelper instance.
     *
     * @param Writer|null $writer Optional Writer instance. If null, a new Writer will be created.
     * @return void
     */
    public function __construct(?Writer $writer = null)
    {
        $this->writer = $writer ?? new Writer;
    }

    /**
     * Prints the stack trace and error message of an exception.
     *
     * If the exception implements ConsoleExceptionInterface, its internal trace will be hidden.
     *
     * @param Throwable $e Holds the exception to print.
     * @return void
     * @noinspection PhpUnnecessaryCurlyVarSyntaxInspection
     */
    public function printTrace(Throwable $e): void
    {
        $eClass = get_class($e);

        $this->writer->colors(
            "{$eClass} <red>{$e->getMessage()}</end><eol/>" .
            '(' . 'thrown in' . " <yellow>{$e->getFile()}</end><white>:{$e->getLine()})</end>"
        );

        // @codeCoverageIgnoreStart
        if ($e instanceof ConsoleExceptionInterface) {
            // Internal exception traces are not printed.
            return;
        }
        // @codeCoverageIgnoreEnd

        $traceStr = '<eol/><eol/><bold>' . 'Stack Trace' . ':</end><eol/><eol/>';

        foreach ($e->getTrace() as $i => $trace) {
            $trace += ['class' => '', 'type' => '', 'function' => '', 'file' => '', 'line' => '', 'args' => []];
            $symbol = $trace['class'] . $trace['type'] . $trace['function'];
            $args   = $this->stringifyArgs($trace['args']);

            $traceStr .= "  <comment>$i)</end> <red>$symbol</end><comment>($args)</end>";
            if ('' !== $trace['file']) {
                $file      = realpath($trace['file']);
                $traceStr .= "<eol/>     <yellow>" . 'at' . " $file</end><white>:{$trace['line']}</end><eol/>";
            }
        }

        $this->writer->colors($traceStr);
    }

    /**
     * Converts an array of arguments into a formatted string.
     *
     * @param array $args Holds the arguments to stringify.
     * @return string Return the formatted argument string.
     */
    public function stringifyArgs(array $args): string
    {
        $holder = [];

        foreach ($args as $arg) {
            $holder[] = $this->stringifyArg($arg);
        }

        return implode(', ', $holder);
    }

    /**
     * Converts an individual argument into a human-readable string.
     *
     * @param mixed $arg Holds the argument to stringify.
     * @return string Return the formatted argument string.
     * @noinspection PhpMissingParamTypeInspection
     */
    protected function stringifyArg($arg): string
    {
        if (is_scalar($arg)) {
            return var_export($arg, true);
        }

        if (is_object($arg)) {
            return method_exists($arg, '__toString') ? (string) $arg : get_class($arg);
        }

        if (is_array($arg)) {
            return '[' . $this->stringifyArgs($arg) . ']';
        }

        return gettype($arg);
    }

    /**
     * Displays help information for command arguments.
     *
     * @param Argument[] $arguments Holds a list of argument definitions.
     * @param string     $header    Holds the optional header message.
     * @param string     $footer    Holds the optional footer message.
     * @return self
     */
    public function showArgumentsHelp(array $arguments, string $header = '', string $footer = ''): self
    {
        $this->showHelp('Arguments', $arguments, $header, $footer);

        return $this;
    }

    /**
     * Displays help information for command options.
     *
     * @param Option[] $options Holds a list of option definitions.
     * @param string   $header  Holds the optional header message.
     * @param string   $footer  Holds the optional footer message.
     * @return self
     */
    public function showOptionsHelp(array $options, string $header = '', string $footer = ''): self
    {
        $this->showHelp('Options', $options, $header, $footer);

        return $this;
    }

    /**
     * Displays help information for available commands.
     *
     * @param Command[] $commands Holds a list of commands.
     * @param string    $header   Holds the optional header message.
     * @param string    $footer   Holds the optional footer message.
     * @return self
     */
    public function showCommandsHelp(array $commands, string $header = '', string $footer = ''): self
    {
        $this->maxCmdName = $commands ? max(array_map(static fn (Command $cmd) => strlen($cmd->getName()), $commands)) : 0;

        $this->showHelp('Commands', $commands, $header, $footer);

        return $this;
    }

    /**
     * Displays a structured help section.
     *
     * @param string $for    Holds the section type (Commands, Options, Arguments).
     * @param array  $items  Holds the items to display.
     * @param string $header Holds the optional header message.
     * @param string $footer Holds the optional footer message.
     * @return void
     * @noinspection PhpUnusedLocalVariableInspection
     */
    protected function showHelp(string $for, array $items, string $header = '', string $footer = ''): void
    {
        if ($header) {
            $this->writer->help_header($header, true);
        }

        $this->writer->eol()->help_category($for . ':', true);

        if (empty($items)) {
            $this->writer->help_text('  (n/a)', true);

            return;
        }

        $space = 4;
        $group = $lastGroup = null;

        $withDefault = $for === 'Options' || $for === 'Arguments';
        foreach (array_values($this->sortItems($items, $padLen, $for)) as $idx => $item) {
            $name  = $this->getName($item);
            if ($for === 'Commands' && $lastGroup !== $group = $item->getGroup()) {
                $this->writer->help_group($group ?: '*', true);
                $lastGroup = $group;
            }
            $desc  = str_replace(["\r\n", "\n"], str_pad("\n", $padLen + $space + 3), $item->getDesc($withDefault));

            if ($idx % 2 == 0) {
                $this->writer->help_item_even('  ' . str_pad($name, $padLen + $space));
                $this->writer->help_description_even($desc, true);
            } else {
                $this->writer->help_item_odd('  ' . str_pad($name, $padLen + $space));
                $this->writer->help_description_odd($desc, true);
            }
        }

        if ($footer) {
            $this->writer->eol()->help_footer($footer, true);
        }
    }

    /**
     * Displays formatted usage examples for a command.
     *
     * @param string $usage Holds the usage string, which may contain `$0` for dynamic command replacement.
     * @return self
     */
    public function showUsage(string $usage): self
    {
        $usage = str_replace('$0', $_SERVER['argv'][0] ?? '[cmd]', $usage);

        if (!str_contains($usage, ' ## ')) {
            $this->writer->eol()->help_category('Usage Examples' . ':', true)->colors($usage)->eol();

            return $this;
        }

        $lines = explode("\n", str_replace(['<eol>', '<eol/>', '</eol>', "\r\n"], "\n", $usage));
        foreach ($lines as $i => &$pos) {
            if (false === $pos = strrpos(preg_replace('~</?\w+/?>~', '', $pos), ' ##')) {
                unset($lines[$i]);
            }
        }

        $maxlen = ($lines ? max($lines) : 0) + 4;
        $usage  = preg_replace_callback('~ ## ~', static function () use (&$lines, $maxlen) {
            return str_pad('# ', $maxlen - array_shift($lines), ' ', STR_PAD_LEFT);
        }, $usage);

        $this->writer->eol()->help_category('Usage Examples' . ':', true)->colors($usage)->eol();

        return $this;
    }

    /**
     * Suggests the closest matching command when an invalid command is entered.
     *
     * @param string $attempted Holds the attempted command name.
     * @param array  $available Holds the list of available command names.
     * @return self
     * @noinspection PhpConditionAlreadyCheckedInspection
     */
    public function showCommandNotFound(string $attempted, array $available): self
    {
        $closest = [];
        foreach ($available as $cmd) {
            $lev = levenshtein($attempted, $cmd);
            if ($lev > 0 || $lev < 5) {
                $closest[$cmd] = $lev;
            }
        }

        $this->writer->error(sprintf('Command %s not found', $attempted), true);
        if ($closest) {
            asort($closest);
            $closest = key($closest);
            $this->writer->bgRed(sprintf('Did you mean %s?', $closest), true);
        }

        return $this;
    }

    /**
     * Sorts items alphabetically and determines the maximum name length for alignment.
     *
     * @param Parameter[]|Command[] $items Holds the items to sort.
     * @param int|null              &$max  Holds the reference to max name length, calculated in this method.
     * @param string                $for   Holds the section type (Commands, Options, Arguments).
     * @return array Return the sorted list of items.
     * @noinspection PhpMissingParamTypeInspection
     */
    protected function sortItems(array $items, &$max = 0, string $for = ''): array
    {
        $max = max(array_map(fn ($item) => strlen($this->getName($item)), $items));

        if ($for === 'Arguments') { // Arguments are positional so must not be sorted
            return $items;
        }

        uasort($items, static function ($a, $b) {
            $aName = $a instanceof GroupableInterface ? $a->getGroup() . $a->getName() : $a->getName();
            $bName = $b instanceof GroupableInterface ? $b->getGroup() . $b->getName() : $b->getName();

            return $aName <=> $bName;
        });

        return $items;
    }

    /**
     * Retrieves the formatted name of a command or parameter.
     *
     * @param Parameter|Command $item Holds the item whose name should be retrieved.
     * @return string Return the formatted name.
     */
    protected function getName(Parameter|Command $item): string
    {
        $name = $item->getName();

        if ($item instanceof Command) {
            return trim(str_pad($name, $this->maxCmdName) . ' ' . $item->alias());
        }

        return $this->getLabel($item);
    }

    /**
     * Retrieves the label of a parameter in a human-readable format.
     *
     * @param Parameter $item Holds the parameter to label.
     * @return string Return the formatted label.
     */
    protected function getLabel(Parameter $item): string
    {
        $name = $item->getName();

        if ($item instanceof Option) {
            $name = $item->getShortName() . '|' . $item->getLongName();
        }

        $variad = $item->isVariadic() ? '...' : '';

        if ($item->isRequired()) {
            return "<$name$variad>";
        }

        return "[$name$variad]";
    }
}
