<?php

/**
 * Part of Omega - Console Package
 * php version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Helper;

use Omega\Console\Exception\RuntimeException;

use function fclose;
use function function_exists;
use function fwrite;
use function is_resource;
use function microtime;
use function proc_close;
use function proc_get_status;
use function proc_open;
use function proc_terminate;
use function stream_get_contents;
use function stream_set_blocking;

/**
 * Shell class.
 *
 * A lightweight wrapper for `proc_open` to execute shell commands with
 * enhanced control. This class allows executing system commands asynchronously
 * or synchronously handling standard input, output, and error streams. It provides
 * process management features, including timeout handling, process termination, and
 * retrieving execution results.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Helper
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html     GPL V3.0+
 * @version    1.0.0
 */
class Shell
{
    /** @var int Standard input descriptor index */
    public const int STDIN_DESCRIPTOR_KEY = 0;

    /** @var int Standard output descriptor index */
    public const int STDOUT_DESCRIPTOR_KEY = 1;

    /** @var int Standard error descriptor index */
    public const int STDERR_DESCRIPTOR_KEY = 2;

    /** @var string Process is initialized but not started */
    public const string STATE_READY = 'ready';

    /** @var string Process has started execution */
    public const string STATE_STARTED = 'started';

    /** @var string Process has been closed */
    public const string STATE_CLOSED = 'closed';

    /** @var string Process has been terminated */
    public const string STATE_TERMINATED = 'terminated';

    /** @var array Default descriptor for stdin on Windows */
    public const array DEFAULT_STDIN_WIN = ['pipe', 'r'];

    /** @var array Default descriptor for stdin on Unix */
    public const array DEFAULT_STDIN_NIX = ['pipe', 'r'];

    /** @var array Default descriptor for stdout on Windows */
    public const array DEFAULT_STDOUT_WIN = ['pipe', 'w'];

    /** @var array Default descriptor for stdout on Unix */
    public const array DEFAULT_STDOUT_NIX = ['pipe', 'w'];

    /** @var array Default descriptor for stderr on Windows */
    public const array DEFAULT_STDERR_WIN = ['pipe', 'w'];

    /** @var array Default descriptor for stderr on Unix */
    public const array DEFAULT_STDERR_NIX = ['pipe', 'w'];

    /** @var bool Whether the process should run asynchronously */
    protected bool $async = false;

    /** @var string|null Working directory for the process */
    protected ?string $cwd = null;

    /** @var array Process descriptors used for proc_open */
    protected array $descriptors;

    /** @var array|null Environment variables passed to the process */
    protected ?array $env = null;

    /** @var int|null Process exit code, set when the process terminates */
    protected ?int $exitCode = null;

    /** @var array Additional options for proc_open */
    protected array $otherOptions = [];

    /** @var array Pointers to stdin, stdout, and stderr */
    protected array $pipes = [];

    /** @var resource|null Process resource returned by proc_open */
    protected $process = null;

    /** @var float Process start time (Unix timestamp) */
    protected float $processStartTime = 0;

    /** @var array|null Process status as returned by proc_get_status */
    protected ?array $processStatus = null;

    /** @var float|null Process timeout in seconds (supports microseconds) */
    protected ?float $processTimeout = null;

    /** @var string Current execution state of the process */
    protected string $state = self::STATE_READY;

    /**
     * Initializes the Shell instance with a command to execute.
     *
     * @param string      $command Holds the command to be executed.
     * @param string|null $input   Holds the input for the process's stdin.
     * @return void
     * @throws RuntimeException If `proc_open` is not available.
     */
    public function __construct(protected string $command, protected ?string $input = null)
    {
        // @codeCoverageIgnoreStart
        if (!function_exists('proc_open')) {
            throw new RuntimeException('Required proc_open could not be found in your PHP setup.');
        }
        // @codeCoverageIgnoreEnd
    }

    /**
     * Prepares the descriptors for standard input, output, and error streams.
     * If not provided, it sets default values based on the operating system.
     *
     * @param array|null $stdin  Holds the optional stdin descriptor (default: OS-specific).
     * @param array|null $stdout Holds the optional stdout descriptor (default: OS-specific).
     * @param array|null $stderr Holds the optional stderr descriptor (default: OS-specific).
     * @return array The prepared descriptors array.
     */
    protected function prepareDescriptors(?array $stdin = null, ?array $stdout = null, ?array $stderr = null): array
    {
        $win = Terminal::isWindows();
        if (!$stdin) {
            $stdin = $win ? self::DEFAULT_STDIN_WIN : self::DEFAULT_STDIN_NIX;
        }
        if (!$stdout) {
            $stdout = $win ? self::DEFAULT_STDOUT_WIN : self::DEFAULT_STDOUT_NIX;
        }
        if (!$stderr) {
            $stderr = $win ? self::DEFAULT_STDERR_WIN : self::DEFAULT_STDERR_NIX;
        }

        return [
            self::STDIN_DESCRIPTOR_KEY  => $stdin,
            self::STDOUT_DESCRIPTOR_KEY => $stdout,
            self::STDERR_DESCRIPTOR_KEY => $stderr,
        ];
    }

    /**
     * Writes the provided input to the process's standard input stream.
     * Ensures the stream is a valid resource before writing to avoid warnings.
     *
     * @return void
     */
    protected function setInput(): void
    {
        //Make sure the pipe is a stream resource before writing to it to avoid a warning
        if (is_resource($this->pipes[self::STDIN_DESCRIPTOR_KEY])) {
            fwrite($this->pipes[self::STDIN_DESCRIPTOR_KEY], $this->input ?? '');
        }
    }

    /**
     * Updates the process status using proc_get_status().
     * Also captures the exit code once the process has stopped running.
     *
     * @return void
     */
    protected function updateProcessStatus(): void
    {
        if ($this->state === self::STATE_STARTED) {
            $this->processStatus = proc_get_status($this->process);

            if ($this->processStatus['running'] === false && $this->exitCode === null) {
                $this->exitCode = $this->processStatus['exitcode'];
            }
        }
    }

    /**
     * Closes all open pipes (stdin, stdout, stderr).
     * Ensures each pipe is a valid resource before closing to avoid warnings.
     *
     * @return void
     */
    protected function closePipes(): void
    {
        //Make sure the pipe are a stream resource before closing them to avoid a warning
        if (is_resource($this->pipes[self::STDIN_DESCRIPTOR_KEY])) {
            fclose($this->pipes[self::STDIN_DESCRIPTOR_KEY]);
        }
        if (is_resource($this->pipes[self::STDOUT_DESCRIPTOR_KEY])) {
            fclose($this->pipes[self::STDOUT_DESCRIPTOR_KEY]);
        }
        if (is_resource($this->pipes[self::STDERR_DESCRIPTOR_KEY])) {
            fclose($this->pipes[self::STDERR_DESCRIPTOR_KEY]);
        }
    }

    /**
     * Waits for the process to complete execution.
     * Sleeps in small intervals to avoid excessive CPU usage and checks for timeouts.
     *
     * @return int|null The process exit code or null if unavailable.
     */
    protected function wait(): ?int
    {
        while ($this->isRunning()) {
            usleep(5000);
            $this->checkTimeout();
        }

        return $this->exitCode;
    }

    /**
     * Checks if the process has exceeded the defined timeout.
     * If so, it terminates the process and throws a RuntimeException.
     *
     * @return void
     * @throws RuntimeException If the process exceeds the timeout limit.
     */
    protected function checkTimeout(): void
    {
        if ($this->processTimeout === null) {
            return;
        }

        $executionDuration = microtime(true) - $this->processStartTime;

        if ($executionDuration > $this->processTimeout) {
            $this->kill();

            throw new RuntimeException('Timeout occurred, process terminated.');
        }
        // @codeCoverageIgnoreStart
    }
    // @codeCoverageIgnoreEnd

    /**
     * Configures process options such as working directory, environment, timeout, and other options.
     *
     * @param string|null $cwd          Holds the working directory.
     * @param array|null  $env          Holds the environment variables.
     * @param float|null  $timeout      Holds the timeout in seconds.
     * @param array       $otherOptions Holds an array of additional proc_open options.
     * @return self
     */
    public function setOptions(
        ?string $cwd = null,
        ?array $env = null,
        ?float $timeout = null,
        array $otherOptions = []
    ): self {
        $this->cwd            = $cwd;
        $this->env            = $env;
        $this->processTimeout = $timeout;
        $this->otherOptions   = $otherOptions;

        return $this;
    }

    /**
     * Executes the command with optional descriptors.
     *
     * @param bool       $async  Whether to run the process asynchronously.
     * @param array|null $stdin  Holds the custom stdin descriptor.
     * @param array|null $stdout Holds the custom stdout descriptor.
     * @param array|null $stderr Holds the custom stderr descriptor.
     * @return self
     * @throws RuntimeException If the process is already running or fails to start.
     */
    public function execute(bool $async = false, ?array $stdin = null, ?array $stdout = null, ?array $stderr = null): self
    {
        if ($this->isRunning()) {
            throw new RuntimeException('Process is already running.');
        }

        $this->descriptors      = $this->prepareDescriptors($stdin, $stdout, $stderr);
        $this->processStartTime = microtime(true);

        $this->process = proc_open(
            $this->command,
            $this->descriptors,
            $this->pipes,
            $this->cwd,
            $this->env,
            $this->otherOptions
        );
        $this->setInput();

        // @codeCoverageIgnoreStart
        if (!is_resource($this->process)) {
            throw new RuntimeException('Bad program could not be started.');
        }
        // @codeCoverageIgnoreEnd

        $this->state = self::STATE_STARTED;

        $this->updateProcessStatus();

        if ($this->async = $async) {
            $this->setOutputStreamNonBlocking();
        } else {
            $this->wait();
        }

        return $this;
    }

    /**
     * Sets the process output stream to non-blocking mode.
     * Ensures the stream is a valid resource before modifying its state.
     *
     * @return bool Return true if successfully set to non-blocking mode, false otherwise.
     * @noinspection PhpReturnValueOfMethodIsNeverUsedInspection
     * @noinspection PhpTernaryExpressionCanBeReplacedWithConditionInspection
     */
    private function setOutputStreamNonBlocking(): bool
    {
        $isRes = is_resource($this->pipes[self::STDOUT_DESCRIPTOR_KEY]);

        return $isRes ? stream_set_blocking($this->pipes[self::STDOUT_DESCRIPTOR_KEY], false) : false;
    }

    /**
     * Retrieves the current execution state of the process.
     *
     * @return string Returns the current execution state of the process.
     */
    public function getState(): string
    {
        return $this->state;
    }

    /**
     * Retrieves the standard output of the process.
     *
     * @return string Return the standard output of the process.
     */
    public function getOutput(): string
    {
        $isRes = is_resource($this->pipes[self::STDOUT_DESCRIPTOR_KEY]);

        return $isRes ? stream_get_contents($this->pipes[self::STDOUT_DESCRIPTOR_KEY]) : '';
    }

    /**
     * Retrieves the error output of the process.
     *
     * @return string Return the error output of the process.
     */
    public function getErrorOutput(): string
    {
        $isRes = is_resource($this->pipes[self::STDERR_DESCRIPTOR_KEY]);

        return $isRes ? stream_get_contents($this->pipes[self::STDERR_DESCRIPTOR_KEY]) : '';
    }


    /**
     * Retrieves the exit code of the process.
     * Updates the process status before returning the exit code.
     *
     * @return int|null Return the exit code of the process, or null if not yet available.
     */
    public function getExitCode(): ?int
    {
        $this->updateProcessStatus();

        return $this->exitCode;
    }

    /**
     * Checks if the process is still running.
     * Updates the process status before returning the result.
     *
     * @return bool Return true if the process is running, false otherwise.
     */
    public function isRunning(): bool
    {
        if (self::STATE_STARTED !== $this->state) {
            return false;
        }

        $this->updateProcessStatus();

        return $this->processStatus['running'];
    }

    /**
     * Retrieves the process ID (PID).
     *
     * @return int|null Return the process ID if running, otherwise null.
     * @noinspection PhpMissingReturnTypeInspection
     */
    public function getProcessId()
    {
        return $this->isRunning() ? $this->processStatus['pid'] : null;
    }

    /**
     * Stops the running process and returns its exit code.
     *
     * @return int|null Return the exit code of the process.
     */
    public function stop(): ?int
    {
        $this->closePipes();

        if (is_resource($this->process)) {
            proc_close($this->process);
        }

        $this->state = self::STATE_CLOSED;

        $this->exitCode = $this->processStatus['exitcode'];

        return $this->exitCode;
    }

    /**
     * Terminates the process immediately.
     * Updates the process state to "terminated."
     *
     * @return void
     */
    public function kill(): void
    {
        if (is_resource($this->process)) {
            proc_terminate($this->process);
        }

        $this->state = self::STATE_TERMINATED;
    }

    /**
     * Destructor to handle resource cleanup.
     * Ensures proper process termination if needed.
     *
     * @return void
     */
    public function __destruct()
    {
        // If async (run in background) => we don't care if it ever closes
        // Otherwise, waited already till it ends itself or timeout occurs, in which case kill it
    }
}
