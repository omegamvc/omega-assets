<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\InputOutput;

use Omega\Console\Input\Reader;
use Omega\Console\Output\Writer;
use Throwable;

use function array_keys;
use function array_map;
use function count;
use function explode;
use function func_get_args;
use function in_array;
use function is_string;
use function ltrim;
use function max;
use function method_exists;
use function range;
use function str_pad;
use function str_replace;
use function strtolower;

/**
 * Writer class.
 *
 * The `Writer` class provides a set of methods designed to format and output text in various colors, styles,
 * and backgrounds to enhance the user interface of command-line applications. These methods allow the user to
 * easily apply text formatting such as bold, underlined, and colored text, as well as backgrounds in various
 * color combinations.
 *
 * The class is ideal for developers looking to improve the visual appeal and readability of console outputs,
 * especially when providing feedback or user prompts in a terminal.
 *
 * **Key Features**:
 *  Text formatting with colors (e.g., red, blue, green, purple, yellow, cyan, white).
 * - Background color customization.
 * - Bold and italic text styles.
 * - Easy-to-use methods for quick formatting.
 *
 * Example:
 * ```php
 * // Assuming the Writer class has been included and initialized
 * $writer = new Writer();
 *
 * // Print text with a blue background
 * $writer->bgBlue("This is some text with a blue background.");
 *
 * // Print bold red text with a yellow background
 * $writer->boldRed("This is bold red text on a yellow background.");
 *
 * // Print a question in cyan
 * $writer->question("What is your favorite color?");
 *
 * // Print an answer in green
 * $writer->green("My favorite color is blue.");
 *
 * // Display a warning message in yellow text with a red background
 * $writer->warn("This is a warning message.");
 *
 * // Using custom line breaks (EOL) for formatting
 * $writer->answer("This answer will have no line break", true);
 *
 * // Display an info message
 * $writer->info("Informational message displayed here.");
 * ```
 * @category   Omega
 * @package    Console
 * @subpackage InputOutput
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 *
 * @phpcs:disable Squiz.Commenting.CommentMaxLineLength
 * @method Writer answer($text, $eol = false) Writes the text as an answer, potentially without a line break.
 * @method Writer bgBlack($text, $eol = false) Writes the text with a black background.
 * @method Writer bgBlue($text, $eol = false) Writes the text with a blue background.
 * @method Writer bgCyan($text, $eol = false) Writes the text with a cyan background.
 * @method Writer bgGreen($text, $eol = false) Writes the text with a green background.
 * @method Writer bgPurple($text, $eol = false) Writes the text with a purple background.
 * @method Writer bgRed($text, $eol = false) Writes the text with a red background.
 * @method Writer bgWhite($text, $eol = false) Writes the text with a white background.
 * @method Writer bgYellow($text, $eol = false) Writes the text with a yellow background.
 * @method Writer black($text, $eol = false) Writes the text in black.
 * @method Writer blackBgBlue($text, $eol = false) Writes the text in black with a blue background.
 * @method Writer blackBgCyan($text, $eol = false) Writes the text in black with a cyan background.
 * @method Writer blackBgGreen($text, $eol = false) Writes the text in black with a green background.
 * @method Writer blackBgPurple($text, $eol = false) Writes the text in black with a purple background.
 * @method Writer blackBgRed($text, $eol = false) Writes the text in black with a red background.
 * @method Writer blackBgWhite($text, $eol = false) Writes the text in black with a white background.
 * @method Writer blackBgYellow($text, $eol = false) Writes the text in black with a yellow background.
 * @method Writer blue($text, $eol = false) Writes the text in blue.
 * @method Writer blueBgBlack($text, $eol = false) Writes the text in blue with a black background.
 * @method Writer blueBgCyan($text, $eol = false) Writes the text in blue with a cyan background.
 * @method Writer blueBgGreen($text, $eol = false) Writes the text in blue with a green background.
 * @method Writer blueBgPurple($text, $eol = false) Writes the text in blue with a purple background.
 * @method Writer blueBgRed($text, $eol = false) Writes the text in blue with a red background.
 * @method Writer blueBgWhite($text, $eol = false) Writes the text in blue with a white background.
 * @method Writer blueBgYellow($text, $eol = false) Writes the text in blue with a yellow background.
 * @method Writer bold($text, $eol = false) Writes the text in bold.
 * @method Writer boldBlack($text, $eol = false) Writes the text in bold black.
 * @method Writer boldBlackBgBlue($text, $eol = false) Writes the text in bold black with a blue background.
 * @method Writer boldBlackBgCyan($text, $eol = false) Writes the text in bold black with a cyan background.
 * @method Writer boldBlackBgGreen($text, $eol = false) Writes the text in bold black with a green background.
 * @method Writer boldBlackBgPurple($text, $eol = false) Writes the text in bold black with a purple background.
 * @method Writer boldBlackBgRed($text, $eol = false) Writes the text in bold black with a red background.
 * @method Writer boldBlackBgWhite($text, $eol = false) Writes the text in bold black with a white background.
 * @method Writer boldBlackBgYellow($text, $eol = false) Writes the text in bold black with a yellow background.
 * @method Writer boldBlue($text, $eol = false) Writes the text in bold blue.
 * @method Writer boldBlueBgBlack($text, $eol = false) Writes the text in bold blue with a black background.
 * @method Writer boldBlueBgCyan($text, $eol = false) Writes the text in bold blue with a cyan background.
 * @method Writer boldBlueBgGreen($text, $eol = false) Writes the text in bold blue with a green background.
 * @method Writer boldBlueBgPurple($text, $eol = false) Writes the text in bold blue with a purple background.
 * @method Writer boldBlueBgRed($text, $eol = false) Writes the text in bold blue with a red background.
 * @method Writer boldBlueBgWhite($text, $eol = false) Writes the text in bold blue with a white background.
 * @method Writer boldBlueBgYellow($text, $eol = false) Writes the text in bold blue with a yellow background.
 * @method Writer boldCyan($text, $eol = false) Writes the text in bold cyan.
 * @method Writer boldCyanBgBlack($text, $eol = false) Writes the text in bold cyan with a black background.
 * @method Writer boldCyanBgBlue($text, $eol = false) Writes the text in bold cyan with a blue background.
 * @method Writer boldCyanBgGreen($text, $eol = false) Writes the text in bold cyan with a green background.
 * @method Writer boldCyanBgPurple($text, $eol = false) Writes the text in bold cyan with a purple background.
 * @method Writer boldCyanBgRed($text, $eol = false) Writes the text in bold cyan with a red background.
 * @method Writer boldCyanBgWhite($text, $eol = false) Writes the text in bold cyan with a white background.
 * @method Writer boldCyanBgYellow($text, $eol = false) Writes the text in bold cyan with a yellow background.
 * @method Writer boldGreen($text, $eol = false) Writes the text in bold green.
 * @method Writer boldGreenBgBlack($text, $eol = false) Writes the text in bold green with a black background.
 * @method Writer boldGreenBgBlue($text, $eol = false) Writes the text in bold green with a blue background.
 * @method Writer boldGreenBgCyan($text, $eol = false) Writes the text in bold green with a cyan background.
 * @method Writer boldGreenBgPurple($text, $eol = false) Writes the text in bold green with a purple background.
 * @method Writer boldGreenBgRed($text, $eol = false) Writes the text in bold green with a red background.
 * @method Writer boldGreenBgWhite($text, $eol = false) Writes the text in bold green with a white background.
 * @method Writer boldGreenBgYellow($text, $eol = false) Writes the text in bold green with a yellow background.
 * @method Writer boldPurple($text, $eol = false) Writes the text in bold purple.
 * @method Writer boldPurpleBgBlack($text, $eol = false) Writes the text in bold purple with a black background.
 * @method Writer boldPurpleBgBlue($text, $eol = false) Writes the text in bold purple with a blue background.
 * @method Writer boldPurpleBgCyan($text, $eol = false) Writes the text in bold purple with a cyan background.
 * @method Writer boldPurpleBgGreen($text, $eol = false) Writes the text in bold purple with a green background.
 * @method Writer boldPurpleBgRed($text, $eol = false) Writes the text in bold purple with a red background.
 * @method Writer boldPurpleBgWhite($text, $eol = false) Writes the text in bold purple with a white background.
 * @method Writer boldPurpleBgYellow($text, $eol = false) Writes the text in bold purple with a yellow background.
 * @method Writer boldRed($text, $eol = false) Writes the text in bold red.
 * @method Writer boldRedBgBlack($text, $eol = false) Writes the text in bold red with a black background.
 * @method Writer boldRedBgBlue($text, $eol = false) Writes the text in bold red with a blue background.
 * @method Writer boldRedBgCyan($text, $eol = false) Writes the text in bold red with a cyan background.
 * @method Writer boldRedBgGreen($text, $eol = false) Writes the text in bold red with a green background.
 * @method Writer boldRedBgPurple($text, $eol = false) Writes the text in bold red with a purple background.
 * @method Writer boldRedBgWhite($text, $eol = false) Writes the text in bold red with a white background.
 * @method Writer boldRedBgYellow($text, $eol = false) Writes the text in bold red with a yellow background.
 * @method Writer boldWhite($text, $eol = false) Writes the text in bold white.
 * @method Writer boldWhiteBgBlack($text, $eol = false) Writes the text in bold white with a black background.
 * @method Writer boldWhiteBgBlue($text, $eol = false) Writes the text in bold white with a blue background.
 * @method Writer boldWhiteBgCyan($text, $eol = false) Writes the text in bold white with a cyan background.
 * @method Writer boldWhiteBgGreen($text, $eol = false) Writes the text in bold white with a green background.
 * @method Writer boldWhiteBgPurple($text, $eol = false) Writes the text in bold white with a purple background.
 * @method Writer boldWhiteBgRed($text, $eol = false) Writes the text in bold white with a red background.
 * @method Writer boldWhiteBgYellow($text, $eol = false) Writes the text in bold white with a yellow background.
 * @method Writer boldYellow($text, $eol = false) Writes the text in bold yellow.
 * @method Writer boldYellowBgBlack($text, $eol = false) Writes the text in bold yellow with a black background.
 * @method Writer boldYellowBgBlue($text, $eol = false) Writes the text in bold yellow with a blue background.
 * @method Writer boldYellowBgCyan($text, $eol = false) Writes the text in bold yellow with a cyan background.
 * @method Writer boldYellowBgGreen($text, $eol = false) Writes the text in bold yellow with a green background.
 * @method Writer boldYellowBgPurple($text, $eol = false) Writes the text in bold yellow with a purple background.
 * @method Writer boldYellowBgRed($text, $eol = false) Writes the text in bold yellow with a red background.
 * @method Writer boldYellowBgWhite($text, $eol = false) Writes the text in bold yellow with a white background.
 * @ method Writer choice($text, $eol = false) Displays a choice prompt for the user, optionally adding an end-of-line character.
 * @method Writer colors($text) Outputs the given text with colors, based on the text's format.
 * @method Writer comment($text, $eol = false) Outputs the given text as a comment, optionally adding an end-of-line character.
 * @method Writer cyan($text, $eol = false) Writes the text in cyan, optionally adding an end-of-line character.
 * @method Writer cyanBgBlack($text, $eol = false) Writes the text in cyan with a black background, optionally adding an end-of-line character.
 * @method Writer cyanBgBlue($text, $eol = false) Writes the text in cyan with a blue background, optionally adding an end-of-line character.
 * @method Writer cyanBgGreen($text, $eol = false) Writes the text in cyan with a green background, optionally adding an end-of-line character.
 * @method Writer cyanBgPurple($text, $eol = false) Writes the text in cyan with a purple background, optionally adding an end-of-line character.
 * @method Writer cyanBgRed($text, $eol = false) Writes the text in cyan with a red background, optionally adding an end-of-line character.
 * @method Writer cyanBgWhite($text, $eol = false) Writes the text in cyan with a white background, optionally adding an end-of-line character.
 * @method Writer cyanBgYellow($text, $eol = false) Writes the text in cyan with a yellow background, optionally adding an end-of-line character.
 * @method Writer eol(int $n = 1) Adds the specified number of end-of-line characters.
 * @method Writer error($text, $eol = false) Writes the text in red to indicate an error, optionally adding an end-of-line character.
 * @method Writer green($text, $eol = false) Writes the text in green, optionally adding an end-of-line character.
 * @method Writer greenBgBlack($text, $eol = false) Writes the text in green with a black background, optionally adding an end-of-line character.
 * @method Writer greenBgBlue($text, $eol = false) Writes the text in green with a blue background, optionally adding an end-of-line character.
 * @method Writer greenBgCyan($text, $eol = false) Writes the text in green with a cyan background, optionally adding an end-of-line character.
 * @method Writer greenBgPurple($text, $eol = false) Writes the text in green with a purple background, optionally adding an end-of-line character.
 * @method Writer greenBgRed($text, $eol = false) Writes the text in green with a red background, optionally adding an end-of-line character.
 * @method Writer greenBgWhite($text, $eol = false) Writes the text in green with a white background, optionally adding an end-of-line character.
 * @method Writer greenBgYellow($text, $eol = false) Writes the text in green with a yellow background, optionally adding an end-of-line character.
 * @method Writer help_category($text, $eol = false) Writes the text as a category in the help section, optionally adding an end-of-line character.
 * @method Writer help_description_even($text, $eol = false) Writes the text as an even description in the help section, optionally adding an end-of-line character.
 * @method Writer help_description_odd($text, $eol = false) Writes the text as an odd description in the help section, optionally adding an end-of-line character.
 * @method Writer help_example($text, $eol = false) Writes the text as an example in the help section, optionally adding an end-of-line character.
 * @method Writer help_footer($text, $eol = false) Writes the text as a footer in the help section, optionally adding an end-of-line character.
 * @method Writer help_group($text, $eol = false) Writes the text as a help group, optionally adding an end-of-line character.
 * @method Writer help_header($text, $eol = false) Writes the text as a header in the help section, optionally adding an end-of-line character.
 * @method Writer help_item_even($text, $eol = false) Writes the text as an even help item, optionally adding an end-of-line character.
 * @method Writer help_item_odd($text, $eol = false) Writes the text as an odd help item, optionally adding an end-of-line character.
 * @method Writer help_summary($text, $eol = false) Writes the text as a summary in the help section, optionally adding an end-of-line character.
 * @method Writer help_text($text, $eol = false) Writes the text as help text, optionally adding an end-of-line character.
 * @method Writer info($text, $eol = false) Writes the text as informational output, optionally adding an end-of-line character.
 * @method Writer logo($text, $eol = false) Writes the text as a logo, optionally adding an end-of-line character.
 * @method Writer ok($text, $eol = false) Writes the text in green with a check mark to indicate success, optionally adding an end-of-line character.
 * @method Writer purple($text, $eol = false) Writes the text in purple, optionally adding an end-of-line character.
 * @method Writer purpleBgBlack($text, $eol = false) Writes the text in purple with a black background, optionally adding an end-of-line character.
 * @method Writer purpleBgBlue($text, $eol = false) Writes the text in purple with a blue background, optionally adding an end-of-line character.
 * @method Writer purpleBgCyan($text, $eol = false) Writes the text in purple with a cyan background, optionally adding an end-of-line character.
 * @method Writer purpleBgGreen($text, $eol = false) Writes the text in purple with a green background, optionally adding an end-of-line character.
 * @method Writer purpleBgRed($text, $eol = false) Writes the text in purple with a red background, optionally adding an end-of-line character.
 * @method Writer purpleBgWhite($text, $eol = false) Writes the text in purple with a white background, optionally adding an end-of-line character.
 * @method Writer purpleBgYellow($text, $eol = false) Writes the text in purple with a yellow background, optionally adding an end-of-line character.
 * @method Writer question($text, $eol = false) Prompts the user with a question, optionally adding an end-of-line character.
 * @method Writer red($text, $eol = false) Writes the text in red, optionally adding an end-of-line character.
 * @method Writer redBgBlack($text, $eol = false) Writes the text in red with a black background, optionally adding an end-of-line character.
 * @method Writer redBgBlue($text, $eol = false) Writes the text in red with a blue background, optionally adding an end-of-line character.
 * @method Writer redBgCyan($text, $eol = false) Writes the text in red with a cyan background, optionally adding an end-of-line character.
 * @method Writer redBgGreen($text, $eol = false) Writes the text in red with a green background, optionally adding an end-of-line character.
 * @method Writer redBgPurple($text, $eol = false) Writes the text in red with a purple background, optionally adding an end-of-line character.
 * @method Writer redBgWhite($text, $eol = false) Writes the text in red with a white background, optionally adding an end-of-line character.
 * @method Writer redBgYellow($text, $eol = false) Writes the text in red with a yellow background, optionally adding an end-of-line character.
 * @method Writer table(array $rows, array $styles = []) Outputs a table with the provided rows and styles.
 * @method Writer version($text, $eol = false) Displays the version text, optionally adding an end-of-line character.
 * @method Writer warn($text, $eol = false) Writes the text in yellow to indicate a warning, optionally adding an end-of-line character.
 * @method Writer white($text, $eol = false) Writes the text in white, optionally adding an end-of-line character.
 * @method Writer yellow($text, $eol = false) Writes the text in yellow, optionally adding an end-of-line character.
 * @method Writer yellowBgBlack($text, $eol = false) Writes the text in yellow with a black background, optionally adding an end-of-line character.
 * @method Writer yellowBgBlue($text, $eol = false) Writes the text in yellow with a blue background, optionally adding an end-of-line character.
 * @method Writer yellowBgCyan($text, $eol = false) Writes the text in yellow with a cyan background, optionally adding an end-of-line character.
 * @method Writer yellowBgGreen($text, $eol = false) Writes the text in yellow with a green background, optionally adding an end-of-line character.
 * @method Writer yellowBgPurple($text, $eol = false) Writes the text in yellow with a purple background, optionally adding an end-of-line character.
 * @method Writer yellowBgRed($text, $eol = false) Writes the text in yellow with a red background, optionally adding an end-of-line character.
 * @method Writer yellowBgWhite($text, $eol = false) Writes the text in yellow with a white background, optionally adding an end-of-line character.
 * @phpcs:enable Squiz.Commenting.CommentMaxLineLength
 */
class Interactor
{
    /** @var Reader Holds the Reader instance. */
    protected Reader $reader;

    /** @var Writer Holds the Writer instance. */
    protected Writer $writer;

    /**
     * Constructor.
     *
     * Initializes the reader and writer instances.
     *
     * @param string|null $input  Holds the input stream path.
     * @param string|null $output Holds the output stream path.
     * @return void
     */
    public function __construct(?string $input = null, ?string $output = null)
    {
        $this->reader = new Reader($input);
        $this->writer = new Writer($output);
    }

    /**
     * Get the reader instance.
     *
     * @return Reader Return the Reader instance.
     */
    public function getReader(): Reader
    {
        return $this->reader;
    }

    /**
     * Get the writer instance.
     *
     * @return Writer Return the Writer instance.
     */
    public function getWriter(): Writer
    {
        return $this->writer;
    }

    /**
     * Confirms if user agrees to the prompt as indicated by the given text.
     *
     * @param string $text    Holds the prompt message, e.g., 'Are you sure?'.
     * @param string $default Holds the default value, one of 'y' or 'n'.
     * @return bool Return true if the user agrees to the prompt.
     */
    public function confirm(string $text, string $default = 'y'): bool
    {
        $choice = $this->choice($text, ['y', 'n'], $default);

        return strtolower($choice[0] ?? $default) === 'y';
    }

    /**
     * Let user make a choice from available choices.
     *
     * @param string $text    Holds the prompt message.
     * @param array  $choices Holds the possible choices for the user.
     * @param mixed  $default Holds the default value if not chosen or invalid.
     * @param bool   $case    Whether the user input should be case-sensitive.
     * @return mixed Return the user input or the default value.
     */
    public function choice(string $text, array $choices, mixed $default = null, bool $case = false): mixed
    {
        $this->writer->question($text);

        $this->listOptions($choices, $default);

        $choice = $this->reader->read($default);

        return $this->isValidChoice($choice, $choices, $case) ? $choice : $default;
    }

    /**
     * Let user make multiple choices from available choices.
     *
     * @param string $text    Holds the prompt message.
     * @param array  $choices Holds the possible choices for the user.
     * @param mixed  $default Holds the default value if not chosen or invalid.
     * @param bool   $case    Whether the user input should be case-sensitive.
     * @return array Return the user input or the default value.
     */
    public function choices(string $text, array $choices, mixed $default = null, bool $case = false): array
    {
        $this->writer->question($text);

        $this->listOptions($choices, $default, true);

        $choice = $this->reader->read($default);

        if (is_string($choice)) {
            $choice = explode(',', str_replace(' ', '', $choice));
        }

        $valid = [];

        foreach ($choice as $option) {
            if ($this->isValidChoice($option, $choices, $case)) {
                $valid[] = $option;
            }
        }

        return $valid ?: (array) $default;
    }

    /**
     * Prompt the user for free input.
     *
     * @param string        $text    Holds the prompt message.
     * @param mixed         $default Holds the default value.
     * @param callable|null $fn      Holds a sanitizer/validator for user input.
     * @param int           $retry   Holds the number of retry attempts on failure.
     * @return mixed Return the user input or the default value.
     */
    public function prompt(string $text, mixed $default = null, ?callable $fn = null, int $retry = 3): mixed
    {
        $error  = 'Invalid value. Please try again!';
        $hidden = func_get_args()[4] ?? false;
        $readFn = ['read', 'readHidden'][(int) $hidden];

        $this->writer->question($text)->answer(null !== $default ? " [$default]: " : ': ');

        try {
            $input = $this->reader->{$readFn}($default, $fn);
        } catch (Throwable $e) {
            $input = '';
            $error = $e->getMessage();
        }

        if ($retry > 0 && $input === '') {
            $this->writer->error($error, true);
            return $this->prompt($text, $default, $fn, $retry - 1, $hidden);
        }

        return ($input === '' ? $default : $input);
    }

    /**
     * Prompt the user for secret input (e.g., password). Unix-only for now.
     *
     * @param string        $text  Holds the prompt message.
     * @param callable|null $fn    Holds a sanitizer/validator for user input.
     * @param int           $retry Holds the number of retry attempts on failure.
     * @return mixed Return the user input.
     */
    public function promptHidden(string $text, ?callable $fn = null, int $retry = 3): mixed
    {
        return $this->prompt($text, null, $fn, $retry, true);
    }

    /**
     * Show the list of available choices.
     *
     * @param array $choices Holds the available choices.
     * @param mixed $default Holds the default value if not chosen or invalid.
     * @param bool  $multi   Whether multiple choices are allowed.
     * @return self
     */
    protected function listOptions(array $choices, mixed $default = null, bool $multi = false): self
    {
        if (!$this->isAssocChoice($choices)) {
            return $this->promptOptions($choices, $default);
        }

        $maxLen = max(array_map('strlen', array_keys($choices)));

        foreach ($choices as $choice => $desc) {
            $this->writer->eol()->choice(str_pad("  [$choice]", $maxLen + 6))->answer($desc);
        }

        $label = $multi ? 'Choices (comma separated)' : 'Choice';

        $this->writer->eol()->question($label);

        return $this->promptOptions(array_keys($choices), $default);
    }

    /**
     * Show the prompt with possible options.
     *
     * @param array $choices Holds the available choices.
     * @param mixed $default Holds the default value.
     * @return self
     */
    protected function promptOptions(array $choices, mixed $default): self
    {
        $options = '';

        foreach ($choices as $choice) {
            $style    = in_array($choice, (array) $default) ? 'boldChoice' : 'choice';
            $options .= "/<$style>$choice</end>";
        }

        $options = ltrim($options, '/');

        $this->writer->colors(" ($options): ");

        return $this;
    }

    /**
     * Check if the user choice is one of the available choices.
     *
     * @param string $choice  Holds the user choice.
     * @param array  $choices Holds the list of available choices.
     * @param bool   $case    Whether the comparison should be case-sensitive.
     * @return bool Return true if valid, false otherwise.
     */
    protected function isValidChoice(string $choice, array $choices, bool $case): bool
    {
        if ($this->isAssocChoice($choices)) {
            $choices = array_keys($choices);
        }

        $fn = ['\strcasecmp', '\strcmp'][(int) $case];

        foreach ($choices as $option) {
            if ($fn($choice, $option) == 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if the choices array is associative.
     *
     * @param array $array Holds the choices array.
     * @return bool Return true if associative, false otherwise.
     */
    protected function isAssocChoice(array $array): bool
    {
        return !empty($array) && array_keys($array) != range(0, count($array) - 1);
    }

    /**
     * Channel method calls to reader/writer.
     *
     * @param string $method    Holds the method name.
     * @param array  $arguments Holds the arguments for the method.
     * @return mixed Return the result of the method call.
     */
    public function __call(string $method, array $arguments)
    {
        if (method_exists($this->reader, $method)) {
            return $this->reader->{$method}(...$arguments);
        }

        return $this->writer->{$method}(...$arguments);
    }
}
