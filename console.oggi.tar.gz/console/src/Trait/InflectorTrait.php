<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Trait;

use function lcfirst;
use function mb_strwidth;
use function mb_substr;
use function str_replace;
use function strlen;
use function substr;
use function trim;
use function ucwords;

/**
 * Provides string transformation methods commonly used in command-line applications.
 *
 * This trait includes methods for:
 * - Converting strings to camel case.
 * - Formatting strings as capitalized words.
 * - Measuring string width.
 * - Extracting substrings with support for multibyte characters.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Trait
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
trait InflectorTrait
{
    /**
     * Converts a string to camel case.
     *
     * Replaces hyphens and underscores with spaces, capitalizes words,
     * removes spaces, and then lowercases the first character.
     *
     * Example:
     * ```php
     * echo $this->toCamelCase('hello-world'); // Outputs: helloWorld
     * ```
     *
     * @param string $string Holds the input string to convert.
     * @return string Return the camel case version of the input string.
     */
    public function toCamelCase(string $string): string
    {
        $words = str_replace(['-', '_'], ' ', $string);
        $words = str_replace(' ', '', ucwords($words));

        return lcfirst($words);
    }

    /**
     * Converts a string into capitalized words.
     *
     * Replaces hyphens and underscores with spaces and capitalizes each word.
     *
     * Example:
     * ```php
     * echo $this->toWords('hello-world'); // Outputs: Hello World
     * ```
     *
     * @param string $string Holds the input string.
     * @return string Return the formatted string with capitalized words.
     */
    public function toWords(string $string): string
    {
        $words = trim(str_replace(['-', '_'], ' ', $string));

        return ucwords($words);
    }

    /**
     * Returns the display width of a string.
     *
     * Uses `mb_strwidth()` if available to correctly measure multibyte characters.
     * Falls back to `strlen()` for single-byte strings.
     *
     * Example:
     * ```php
     * echo $this->strWidth('Omega'); // Outputs: 5 (correct multibyte width)
     * ```
     *
     * @param string $string Holds the input string.
     * @return int Return the width of the string in characters.
     */
    public function strWidth(string $string): int
    {
        if (function_exists('mb_strwidth')) {
            return mb_strwidth($string);
        }

        return strlen($string);
    }

    /**
     * Extracts a portion of a string.
     *
     * Uses `mb_substr()` if available for multibyte character support;
     * otherwise, falls back to `substr()`.
     *
     * Example:
     * ```php
     * echo $this->substr('OmegaFramework', 5, 5); // Outputs: Frame
     * ```
     *
     * @param string   $string Holds the input string.
     * @param int      $start  Holds the starting position (zero-based index).
     * @param int|null $length Holds the length of the substring (null for the rest of the string).
     * @return string Return the extracted substring.
     */
    public function substr(string $string, int $start, ?int $length = null): string
    {
        if (function_exists('mb_substr')) {
            return mb_substr($string, $start, $length);
        }

        return substr($string, $start, $length);
    }
}
