<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console;

use Omega\Console\Exception\InvalidArgumentException;
use Omega\Console\Helper\OutputHelper;
use Omega\Console\Input\Command;
use Omega\Console\InputOutput\Interactor;
use ReflectionClass;
use ReflectionException;
use ReflectionFunction;
use Throwable;

use function array_diff_key;
use function array_fill_keys;
use function array_keys;
use function count;
use function func_num_args;
use function in_array;
use function is_array;
use function is_int;
use function method_exists;
use function sprintf;

/**
 * The main class for the Omega Console package.
 *
 * This class manages commands, arguments, and execution flow for the console application.
 *
 * @category   Omega
 * @package    Console
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
class Console
{
    /** @var Command[] List of registered commands */
    protected array $commands = [];

    /** @var array Raw command-line arguments (argv) */
    protected array $argv = [];

    /** @var array List of command aliases [alias => command_name] */
    protected array $aliases = [];

    /** @var string ASCII art logo displayed in the console */
    protected string $logo = '';

    /** @var string Custom help screen content */
    protected string $help = '';

    /** @var string Name of the default command */
    protected string $default = '__default__';

    /** @var ?Interactor The input/output interactor */
    protected ?Interactor $io = null;

    /** @var callable The exit handler function */
    protected $onExit;

    /**
     * @var callable|null Exception handler function.
     * The function receives an exception and an exit code. It may rethrow the exception, exit the program, or log it.
     */
    protected $onException = null;

    /**
     * Constructor.
     *
     * @param string        $name    Holds the application name.
     * @param string        $version Holds the application version.
     * @param callable|null $onExit  Holds custom exit handler (default: calls `exit($code)`).
     * @reurn void
     */
    public function __construct(
        protected string $name,
        protected string $version = '0.0.1',
        ?callable $onExit = null
    ) {
        $this->onExit = $onExit ?? static fn (int $exitCode = 0) => exit($exitCode);

        $this->setCommand(
            '__default__',
            'Default command',
            '', true
        )->on([$this, 'showHelp'], 'help');
    }

    /**
     * Gets the application name.
     *
     * @return string Return the application name.
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Gets the application version.
     *
     * @return string Return the application version.
     */
    public function getVersion(): string
    {
        return $this->version;
    }

    /**
     * Gets all registered commands (excluding the default command).
     *
     * @return Command[] Return an array of registered command.
     */
    public function getCommands(): array
    {
        $commands = $this->commands;

        unset($commands['__default__']);

        return $commands;
    }

    /**
     * Gets the raw command-line arguments (argv).
     *
     * @return array Return an array of raw command-line arguments.
     */
    public function getArgv(): array
    {
        return $this->argv;
    }

    /**
     * Gets or sets the ASCII art logo.
     *
     * @param string|null $logo Holds the logo text (optional)
     * @return Console|string Return the current instance if setting the logo, otherwise the logo string
     */
    public function setLogo(?string $logo = null): Console|string
    {
        if (func_num_args() === 0) {
            return $this->logo;
        }

        $this->logo = $logo;

        return $this;
    }

    /**
     * Registers a new command and returns it.
     *
     * @param string $name         Holds rhe command name.
     * @param string $desc         Holds a short description.
     * @param string $alias        Holds an optional alias.
     * @param bool   $allowUnknown Allow unknown parameters.
     * @param bool   $default      Set as default command.
     * @return Command Return the created command instance.
     */
    public function setCommand(
        string $name,
        string $desc = '',
        string $alias = '',
        bool $allowUnknown = false,
        bool $default = false
    ): Command {
        $command = new Command($name, $desc, $allowUnknown, $this);

        $this->addCommand($command, $alias, $default);

        return $command;
    }

    /**
     * Adds a pre-configured command.
     *
     * @param Command $command Holds the command instance
     * @param string  $alias   Holds an optional alias
     * @param bool    $default Set as the default command
     * @return self
     * @throws InvalidArgumentException If the command or alias is already registered
     */
    public function addCommand(Command $command, string $alias = '', bool $default = false): self
    {
        $name = $command->getName();

        if (
            $this->commands[$name] ??
            $this->aliases[$name] ??
            $this->commands[$alias] ??
            $this->aliases[$alias] ??
            null
        ) {
            throw new InvalidArgumentException(sprintf('Command "%s" already added', $name));
        }

        if ($alias) {
            $command->alias($alias);
            $this->aliases[$alias] = $name;
        }

        if ($default) {
            $this->default = $name;
        }

        $this->commands[$name] = $command->setVersion($this->version)->onExit($this->onExit)->bind($this);

        return $this;
    }

    /**
     * Sets the default command.
     *
     * @param string $commandName Holds the name of the default command
     * @return self
     * @throws InvalidArgumentException If the command does not exist
     */
    public function defaultCommand(string $commandName): self
    {
        if (!isset($this->commands[$commandName])) {
            throw new InvalidArgumentException(sprintf('Command "%s" does not exist', $commandName));
        }

        $this->default = $commandName;

        return $this;
    }

    /**
     * Get the name of the default command.
     *
     * @return string|null Return the name of the default command, or null if not set
     */
    public function getDefaultCommand(): ?string
    {
        return $this->default;
    }

    /**
     * Groups commands set within the callable.
     *
     * @param string   $group Holds the group name
     * @param callable $fn    Holds the callable that receives Application instance and adds commands.
     * @return self
     */
    public function setGroup(string $group, callable $fn): self
    {
        $old = array_fill_keys(array_keys($this->commands), true);

        $fn($this);
        foreach (array_diff_key($this->commands, $old) as $cmd) {
            $cmd->setGroup($group);
        }

        return $this;
    }

    /**
     * Gets matching command for given argv.
     *
     * @param array $argv
     * @return Command
     */
    public function getCommandFor(array $argv): Command
    {
        $argv += [null, null, null];

        return
            // cmd
            $this->commands[$argv[1]]
            // cmd alias
            ?? $this->commands[$this->aliases[$argv[1]] ?? null]
            // default.
            ?? $this->commands[$this->default];
    }

    /**
     * Gets or sets io.
     *
     * @param Interactor|null $io
     * @return Console|Interactor|null|static
     */
    public function getIo(?Interactor $io = null): Console|Interactor|null|static
    {
        if ($io || !$this->io) {
            $this->io = $io ?? new Interactor;
        }

        if (func_num_args() === 0) {
            return $this->io;
        }

        return $this;
    }

    /**
     * Parses command-line arguments without executing the command.
     *
     * @param array $argv Holds the command-line arguments
     * @return Command Return the matched and parsed command
     */
    public function parse(array $argv): Command
    {
        $this->argv = $argv;

        $command = $this->getCommandFor($argv);
        $aliases = $this->getAliasesFor($command);

        // Eat the cmd name!
        foreach ($argv as $i => $arg) {
            if (in_array($arg, $aliases)) {
                unset($argv[$i]);

                break;
            }

            if ($arg[0] === '-') {
                break;
            }
        }

        return $command->parse($argv);
    }

    /**
     * Sets exception handler callback.
     *
     * The callback receives exception & exit code. It may rethrow exception
     * or may exit the program or just log exception and do nothing else.
     *
     * @param callable $fn
     * @return self
     */
    public function onException(callable $fn): self
    {
        $this->onException = $fn;

        return $this;
    }

    /**
     * Handles command execution and error management.
     *
     * @param array $argv Holds the command-line arguments
     * @return mixed Return the result of the executed command
     */
    public function handle(array $argv): mixed
    {
        if ($this->default === '__default__' && count($argv) < 2) {
            return $this->showHelp();
        }

        $exitCode = 255;

        try {
            $command  = $this->parse($argv);
            $result   = $this->doAction($command);
            $exitCode = is_int($result) ? $result : 0;
        } catch (Throwable $e) {
            isset($this->onException) && ($this->onException)($e, $exitCode);
            $this->outputHelper()->printTrace($e);
        }

        return ($this->onExit)($exitCode);
    }

    /**
     * Get aliases for given command.
     *
     * @param Command $command
     * @return array
     */
    protected function getAliasesFor(Command $command): array
    {
        $aliases = [$name = $command->getName()];

        foreach ($this->aliases as $alias => $cmd) {
            if (in_array($name, [$alias, $cmd], true)) {
                $aliases[] = $alias;
                $aliases[] = $cmd;
            }
        }

        return $aliases;
    }

    /**
     * Sets or gets the custom help screen contents.
     *
     * @param string|null $help
     * @return string|static
     */
    public function help(?string $help = null): string|static
    {
        if (func_num_args() === 0) {
            return $this->help;
        }

        $this->help = $help;

        return $this;
    }

    /**
     * Show custom help screen if one is set, otherwise shows the default one.
     *
     * @return mixed
     */
    public function showHelp(): mixed
    {
        if ($help = $this->help()) {
            $writer = $this->getIo()->getWriter();
            $writer->write($help, true);

            return ($this->onExit)();
        }

        return $this->showDefaultHelp();
    }

    /**
     * Shows command help then aborts.
     * @return mixed
     * @noinspection PhpUnnecessaryCurlyVarSyntaxInspection
     */
    public function showDefaultHelp(): mixed
    {
        $writer = $this->getIo()->getWriter();
        $header = "{$this->name}, " . 'version' . " {$this->version}";
        $footer = 'Run `<command> --help` for specific help';

        if ($this->logo) {
            $writer->logo($this->logo, true);
        }

        $this->outputHelper()->showCommandsHelp($this->getCommands(), $header, $footer);

        return ($this->onExit)();
    }

    /**
     * @return OutputHelper
     */
    protected function outputHelper(): OutputHelper
    {
        $writer = $this->getIo()->getWriter();

        return new OutputHelper($writer);
    }

    /**
     * Invoke command action.
     *
     * @param Command $command
     * @return mixed
     * @throws ReflectionException
     */
    protected function doAction(Command $command): mixed
    {
        if ($command->getName() === '__default__') {
            return $this->notFound();
        }

        // Let the command collect more data (if missing or needs confirmation)
        $command->interact($this->getIo());

        if (!$command->action() && !method_exists($command, 'execute')) {
            return null;
        }

        $params = [];
        $values = $command->getValues();
        // We prioritize action to be in line with commander.js!
        $action = $command->action() ?? [$command, 'execute'];

        foreach ($this->getActionParameters($action) as $param) {
            $params[] = $values[$param->getName()] ?? null;
        }

        return $action(...$params);
    }

    /**
     * Command not found handler.
     *
     * @return mixed
     */
    protected function notFound(): mixed
    {
        $available = array_keys($this->getCommands() + $this->aliases);
        $this->outputHelper()->showCommandNotFound($this->argv[1], $available);

        return ($this->onExit)(127);
    }

    /**
     * @param callable $action
     * @return array
     * @throws ReflectionException
     */
    protected function getActionParameters(callable $action): array
    {
        $reflex = is_array($action)
            ? (new ReflectionClass($action[0]))->getMethod($action[1])
            : new ReflectionFunction($action);

        return $reflex->getParameters();
    }
}
