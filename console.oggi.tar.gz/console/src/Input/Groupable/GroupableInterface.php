<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Input\Groupable;

/**
 * Interface for objects that support grouping.
 *
 * Provides methods to assign an object to a group and retrieve its group name.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Input\Groupable
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
interface GroupableInterface
{
    /**
     * Assigns the object to a specified group.
     *
     * @param string $group Holds the name of the group.
     * @return self Returns the instance for method chaining.
     */
    public function setGroup(string $group): self;

    /**
     * Retrieves the name of the group the object belongs to.
     *
     * @return string Return the group name.
     */
    public function getGroup(): string;
}
