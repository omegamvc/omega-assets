<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Input;

use Omega\Console\Input\Parameter\Parameter;

use function preg_match;
use function preg_split;
use function str_contains;
use function str_replace;

/**
 * CLI Option representation.
 *
 * This class defines a command-line option, extending the `Parameter` class.
 * It handles short and long option names, default values, and type identification.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Input
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
class Option extends Parameter
{
    /** @var string The short (single-dash) version of the option. */
    protected string $short = '';

    /** @var string The long (double-dash) version of the option. */
    protected string $long = '';

    /**
     * {@inheritdoc}
     * @noinspection RegExpRedundantEscape
     */
    protected function parse(string $raw): void
    {
        if (str_contains($raw, '-with-')) {
            $this->default = false;
        } elseif (str_contains($raw, '-no-')) {
            $this->default = true;
        }

        $parts = preg_split('/[\s,\|]+/', $raw);

        $this->short = $this->long = $parts[0];
        if (isset($parts[1])) {
            $this->long = $parts[1];
        }

        $this->name = str_replace(['--', 'no-', 'with-'], '', $this->long);
    }

    /**
     * Get the long name of the option.
     *
     * @return string The long name of the option.
     */
    public function getLongName(): string
    {
        return $this->long;
    }

    /**
     * Get the short name of the option.
     *
     * @return string The short name of the option.
     */
    public function getShortName(): string
    {
        return $this->short;
    }

    /**
     * Check if this option matches the given argument.
     *
     * @param string $arg The argument to check against.
     * @return bool True if the argument matches the option, otherwise false.
     */
    public function isMatches(string $arg): bool
    {
        return $this->short === $arg || $this->long === $arg;
    }

    /**
     * Determine if the option is a boolean flag.
     *
     * An option is considered boolean if it contains `--no-` or `--with-` in its name.
     *
     * @return bool True if the option is a boolean flag, otherwise false.
     * @noinspection RegExpRedundantEscape
     */
    public function isBoolean(): bool
    {
        return preg_match('/\-no-|\-with-/', $this->long) > 0;
    }
}
