<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Input\Parser;

use Omega\Console\Exception\InvalidArgumentException;
use Omega\Console\Exception\InvalidParameterException;
use Omega\Console\Exception\RuntimeException;
use Omega\Console\Helper\Normalizer;
use Omega\Console\Input\Argument;
use Omega\Console\Input\Option;
use Omega\Console\Input\Parameter\Parameter;

use function array_diff_key;
use function array_filter;
use function array_key_exists;
use function array_merge;
use function array_shift;
use function count;
use function in_array;
use function reset;
use function sprintf;
use function substr;

/**
 * Parses command-line arguments (argv) for CLI applications.
 *
 * This abstract class provides methods for parsing, normalizing, and validating
 * command-line arguments and options. It supports variadic parameters, default values,
 * and argument/option validation.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Input\Parser
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
abstract class Parser
{
    /** @var string|null The last encountered variadic option name */
    protected ?string $lastVariadic = null;

    /** @var Normalizer Responsible for normalizing argument and option values */
    protected Normalizer $normalizer;

    /** @var array<string, Option> Registered options */
    private array $options = [];

    /** @var array<string, Argument> Registered arguments */
    private array $arguments = [];

    /** @var array<string, mixed> Parsed values indexed by option/argument name */
    private array $values = [];

    /**
     * Parses the given command-line arguments.
     *
     * @param array $argv The list of command-line arguments. The first item (script name) is ignored.
     * @return self
     * @throws RuntimeException If a required argument is missing or an invalid argument is provided.
     */
    public function parse(array $argv): self
    {
        $this->normalizer = new Normalizer;

        array_shift($argv);

        $argv    = $this->normalizer->normalizeArgs($argv);
        $count   = count($argv);
        $literal = false;

        for ($i = 0; $i < $count; $i++) {
            [$arg, $nextArg] = [$argv[$i], $argv[$i + 1] ?? null];

            if ($arg === '--') {
                $literal = true;
            } elseif ($arg[0] !== '-' || $literal) {
                $this->parseArgs($arg);
            } else {
                $i += (int) $this->parseOptions($arg, $nextArg);
            }
        }

        $this->validate();

        return $this;
    }

    /**
     * Unsets a registered argument or option.
     *
     * @param string $name The name of the argument or option to unset.
     * @return self
     */
    public function unset(string $name): self
    {
        unset($this->values[$name], $this->arguments[$name], $this->options[$name]);

        return $this;
    }

    /**
     * Checks whether an argument or option is registered.
     *
     * @param int|string $attribute The name or index of the argument/option.
     * @return bool True if registered, false otherwise.
     */
    public function isRegistered(int|string $attribute): bool
    {
        return array_key_exists($attribute, $this->values);
    }

    /**
     * Retrieves all registered options.
     *
     * @return Option[] Return an array of registered options.
     */
    public function getAllOptions(): array
    {
        return $this->options;
    }

    /**
     * Retrieves all registered arguments.
     *
     * @return Argument[] Return an array of registered arguments.
     */
    public function getAllArguments(): array
    {
        return $this->arguments;
    }

    /**
     * Magic getter for retrieving a parsed value by its key.
     *
     * @param string $key The name of the argument/option.
     * @return mixed The corresponding value or null if not set.
     */
    public function __get(string $key): mixed
    {
        return $this->values[$key] ?? null;
    }

    /**
     * Retrieves command-line arguments (excluding options).
     *
     * @return array An associative array of parsed arguments.
     */
    public function getArgs(): array
    {
        return array_diff_key($this->values, $this->options);
    }

    /**
     * Retrieves all parsed values indexed by their attribute names.
     *
     * @param bool $withDefaults Whether to include default values.
     * @return array The parsed values.
     */
    public function getValues(bool $withDefaults = true): array
    {
        $values            = $this->values;
        $values['version'] = $this->version ?? null;

        if (!$withDefaults) {
            unset($values['help'], $values['version'], $values['verbosity']);
        }

        return $values;
    }

    /**
     * Parses a single argument.
     *
     * @param string $arg The argument to parse.
     * @return mixed
     * @noinspection PhpMissingReturnTypeInspection
     * @noinspection PhpReturnDocTypeMismatchInspection
     */
    protected function parseArgs(string $arg)
    {
        if ($this->lastVariadic) {
            return $this->set($this->lastVariadic, $arg, true);
        }

        if (!$argument = reset($this->arguments)) {
            return $this->set(null, $arg);
        }

        $this->setValue($argument, $arg);

        // Otherwise we will always collect same arguments again!
        if (!$argument->isVariadic()) {
            array_shift($this->arguments);
        }
    }

    /**
     * Parses an option from the command-line input.
     *
     * @param string      $arg     The option name.
     * @param string|null $nextArg The next argument, if available.
     * @return bool Whether the next argument was consumed.
     * @noinspection PhpStrFunctionsInspection
     * @noinspection PhpTernaryExpressionCanBeReplacedWithConditionInspection
     */
    protected function parseOptions(string $arg, ?string $nextArg = null): bool
    {
        $value = substr($nextArg ?? '', 0, 1) === '-' ? null : $nextArg;

        if (null === $option  = $this->getOptionFor($arg)) {
            return $this->handleUnknown($arg, $value);
        }

        $this->lastVariadic = $option->isVariadic() ? $option->getAttributeName() : null;

        return false === $this->emit($option->getAttributeName(), $value) ? false : $this->setValue($option, $value);
    }

    /**
     * Retrieves the option corresponding to a given argument name.
     *
     * @param string $arg The argument name.
     * @return Option|null The corresponding option or null if not found.
     */
    protected function getOptionFor(string $arg): ?Option
    {
        foreach ($this->options as $option) {
            if ($option->isMatches($arg)) {
                return $option;
            }
        }

        return null;
    }

    /**
     * Sets the value of an option.
     *
     * This method normalizes the given value according to the parameter's requirements
     * and assigns it to the corresponding option.
     *
     * @param Parameter   $parameter The parameter whose value is being set.
     * @param string|null $value     The value to assign.
     * @return bool Indicates whether the next argument was consumed.
     */
    protected function setValue(Parameter $parameter, ?string $value = null): bool
    {
        $name  = $parameter->getAttributeName();
        $value = $this->normalizer->normalizeValue($parameter, $value);

        return $this->set($name, $value, $parameter->isVariadic());
    }

    /**
     * Assigns a raw value to an option or argument.
     *
     * If the key is null, the value is stored in a numeric index. If the key is variadic,
     * the value is merged into an array.
     *
     * @param string|null $key      The name of the option/argument or null for unnamed values.
     * @param mixed       $value    The value to store.
     * @param bool        $variadic Whether the value belongs to a variadic parameter.
     * @return bool Indicates whether the value is significant (not true, false, or null).
     */
    protected function set(string|null $key, mixed $value, bool $variadic = false): bool
    {
        if (null === $key) {
            $this->values[] = $value;
        } elseif ($variadic) {
            $this->values[$key] = array_merge($this->values[$key], (array) $value);
        } else {
            $this->values[$key] = $value;
        }

        return !in_array($value, [true, false, null], true);
    }

    /**
     * Validates whether all required arguments and options have appropriate values.
     *
     * This method checks that all required parameters have been provided and throws an
     * exception if any are missing.
     *
     * @return void
     * @throws RuntimeException If a required parameter is missing a value.
     */
    protected function validate(): void
    {
        /** @var Parameter[] $missingItems */
        /** @var Parameter $item */
        $missingItems = array_filter(
            $this->options + $this->arguments,
            fn ($item) => $item->isRequired() && in_array($this->values[$item->getAttributeName()], [null, []])
        );

        foreach ($missingItems as $item) {
            [$name, $label] = [$item->getName(), 'Argument'];
            if ($item instanceof Option) {
                [$name, $label] = [$item->getLongName(), 'Option'];
            }

            throw new RuntimeException(sprintf('%1$s "%2$s" is required', $label, $name));
        }
    }

    /**
     * Registers a new argument or option.
     *
     * @param Parameter $param The parameter to register.
     * @return void
     */
    protected function register(Parameter $param): void
    {
        $this->ifAlreadyRegistered($param);

        $name = $param->getAttributeName();
        if ($param instanceof Option) {
            $this->options[$name] = $param;
        } else {
            $this->arguments[$name] = $param;
        }

        $this->set($name, $param->getDefault());
    }

    /**
     * Ensures that a given parameter is not already registered.
     *
     * @param Parameter $param The parameter to check.
     * @return void
     * @throws InvalidArgumentException If the parameter is already registered.
     */
    protected function ifAlreadyRegistered(Parameter $param): void
    {
        if ($this->isRegistered($param->getAttributeName())) {
            throw new InvalidParameterException(
                sprintf(
                    'The parameter "%s" is already registered',
                    $param instanceof Option
                        ? $param->getLongName()
                        : $param->getName()
                )
            );
        }
    }

    /**
     * Handles an unknown option.
     *
     * @param string      $arg   The unknown option name.
     * @param string|null $value The corresponding value.
     * @throws RuntimeException If unknown options are not allowed.
     * @return mixed
     */
    abstract protected function handleUnknown(string $arg, ?string $value = null): mixed;

    /**
     * Emits an event when an option is encountered.
     *
     * @param string $event The event name (option name).
     * @param mixed  $value The option value.
     * @return mixed
     * @noinspection PhpMissingParamTypeInspection
     */
    abstract protected function emit(string $event, $value = null): mixed;
}
