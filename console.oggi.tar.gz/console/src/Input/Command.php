<?php

declare(strict_types=1);

namespace Omega\Console\Input;

use Omega\Console\Console;
use Omega\Console\Exception\InvalidParameterException;
use Omega\Console\Exception\RuntimeException;
use Omega\Console\Input\Groupable\GroupableInterface;
use Omega\Console\Input\Parser\Parser;
use Omega\Console\Helper\OutputHelper;
use Omega\Console\InputOutput\Interactor;
use Omega\Console\Output\ProgressBar;
use Omega\Console\Output\Writer;
use Omega\Console\Trait\InflectorTrait;
use Closure;

use function array_filter;
use function array_keys;
use function end;
use function explode;
use function func_num_args;
use function sprintf;
use function str_contains;
use function strstr;

/**
 * Parser aware Command for the cli (based on tj/commander.js).
 */
class Command extends Parser implements GroupableInterface
{
    use InflectorTrait;

    /**
     * @noinspection PhpMissingFieldTypeInspection
     */
    protected $action = null;

    protected string $group;

    protected string $version = '';

    protected string $usage = '';

    protected ?string $alias = null;

    protected string $logo = '';

    protected string $help = '';

    private array $events = [];

    private bool $argVariadic = false;

    /**
     * Constructor.
     *
     * @param string $name
     * @param string $desc
     * @param bool   $allowUnknown
     * @param Console|null $console
     */
    public function __construct(
        protected string $name,
        protected string $desc = '',
        protected bool $allowUnknown = false,
        protected ?Console $console = null
    ) {
        $this->setDefaults();
        $this->setGroup(str_contains($name, ':') ? strstr($name, ':', true) : '');
    }

    /**
     * Sets default options, actions and exit handler.
     * @noinspection PhpBooleanCanBeSimplifiedInspection
     */
    protected function setDefaults(): self
    {
        $this->setOption('-h, --help', 'Show help')->on([$this, 'showHelp']);
        $this->setOption('-V, --version', 'Show version')->on([$this, 'showVersion']);
        $this->setOption('-v, --verbosity', 'Verbosity level', null, 0)->on(
            fn () => $this->set('verbosity', ($this->verbosity ?? 0) + 1) && false
        );

        $this->onExit(static fn ($exitCode = 0) => exit($exitCode));

        return $this;
    }

    /**
     * Sets version.
     */
    public function setVersion(string $version): self
    {
        $this->version = $version;

        return $this;
    }

    /**
     * Gets command name.
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Gets command description.
     */
    public function getDesc(): string
    {
        return $this->desc;
    }

    /**
     * Sets command group.
     */
    public function setGroup(string $group): self
    {
        $this->group = $group;

        return $this;
    }

    /**
     * Gets command group.
     */
    public function getGroup(): string
    {
        return $this->group;
    }

    /**
     * Get the app this command belongs to.
     */
    public function getConsole(): ?Console
    {
        return $this->console;
    }

    /**
     * Bind command to the app.
     */
    public function bind(?Console $console = null): self
    {
        $this->console = $console;

        return $this;
    }

    /**
     * Sets or gets the ASCII art logo.
     *
     * @param string|null $logo
     *
     * @return string|self
     */
    public function setLogo(?string $logo = null): string|self
    {
        if (func_num_args() === 0) {
            return $this->logo;
        }

        $this->logo = $logo;

        return $this;
    }

    /**
     * Registers argument definitions (all at once). Only last one can be variadic.
     */
    public function setArguments(string $definitions): self
    {
        $definitions = explode(' ', $definitions);

        foreach ($definitions as $raw) {
            $this->setArgument($raw);
        }

        return $this;
    }

    /**
     * Register an argument.
     */
    public function setArgument(string $raw, string $desc = '', $default = null): self
    {
        $argument = new Argument($raw, $desc, $default);

        if ($this->argVariadic) {
            throw new InvalidParameterException('Only last argument can be variadic');
        }

        if ($argument->isVariadic()) {
            $this->argVariadic = true;
        }

        $this->register($argument);

        return $this;
    }

    /**
     * Registers new option.
     */
    public function setOption(string $raw, string $desc = '', ?callable $filter = null, $default = null): self
    {
        $option = new Option($raw, $desc, $default, $filter);

        $this->register($option);

        return $this;
    }

    /**
     * Gets user options (i.e. without defaults).
     */
    public function getOptions(): array
    {
        $options = $this->getAllOptions();

        unset($options['help'], $options['version'], $options['verbosity']);

        return $options;
    }

    /**
     * Gets or sets usage info.
     *
     * @param string|null $usage
     *
     * @return string|self
     */
    public function usage(?string $usage = null): string|self
    {
        if (func_num_args() === 0) {
            return $this->usage;
        }

        $this->usage = $usage;

        return $this;
    }

    /**
     * Gets or sets alias.
     *
     * @param string|null $alias
     *
     * @return string|self
     * @noinspection PhpMissingReturnTypeInspection
     */
    public function alias(?string $alias = null)
    {
        if (func_num_args() === 0) {
            return $this->alias;
        }

        $this->alias = $alias;

        return $this;
    }

    /**
     * Sets event handler for last (or given) option.
     */
    public function on(callable $fn, ?string $option = null): self
    {
        $names = array_keys($this->getAllOptions());

        $this->events[$option ?? end($names)] = $fn;

        return $this;
    }

    /**
     * Register exit handler.
     */
    public function onExit(callable $fn): self
    {
        $this->events['_exit'] = $fn;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    protected function handleUnknown(string $arg, ?string $value = null): mixed
    {
        if ($this->allowUnknown) {
            return $this->set($this->toCamelCase($arg), $value);
        }

        $values = array_filter($this->getValues(false));

        // Has some value, error!
        if ($values) {
            throw new RuntimeException(sprintf('Option "%s" not registered', $arg));
        }

        // Has no value, show help!
        return $this->showHelp();
    }

    /**
     * Sets or gets the custom help screen contents.
     *
     * @param string|null $help
     *
     * @return string|static
     */
    public function setHelp(?string $help = null): static|string
    {
        if (func_num_args() === 0) {
            return $this->help;
        }

        $this->help = $help;

        return $this;
    }

    /**
     * Show custom help screen if one is set, otherwise shows the default one.
     */
    public function showHelp(): mixed
    {
        if ($help = $this->setHelp()) {
            $writer = $this->getIo()->getWriter();
            $writer->write($help, true);

            return $this->emit('_exit', 0);
        }

        return $this->showDefaultHelp();
    }

    /**
     * Shows command help then aborts.
     * @noinspection PhpUnnecessaryCurlyVarSyntaxInspection
     */
    public function showDefaultHelp(): mixed
    {
        $io     = $this->getIo();
        $helper = new OutputHelper($io->getWriter());
        $app    = $this->getConsole();

        if (($logo = $this->setLogo()) || ($app && ($logo = $app->setLogo()) && $app->getDefaultCommand() === $this->name)) {
            $io->logo($logo, true);
        }

        $io->help_header('Command' . " {$this->name}, " . 'version' . " {$this->version}", true)->eol();
        $io->help_summary($this->desc, true)->eol();
        $io->help_text('Usage' . ': ')->help_example("{$this->name} " . '[OPTIONS...] [ARGUMENTS...]', true);

        $helper
            ->showArgumentsHelp($this->getAllArguments())
            ->showOptionsHelp($this->getAllOptions(), '', 'Legend: <required> [optional] variadic...');

        if ($this->usage) {
            $helper->showUsage($this->usage);
        }

        return $this->emit('_exit', 0);
    }

    /**
     * Shows command version then aborts.
     */
    public function showVersion(): mixed
    {
        $this->getWriter()->version($this->version, true);

        return $this->emit('_exit', 0);
    }

    /**
     * {@inheritdoc}
     * @noinspection PhpMixedReturnTypeCanBeReducedInspection
     */
    public function emit(string $event, $value = null): mixed
    {
        if (empty($this->events[$event])) {
            return null;
        }

        return ($this->events[$event])($value);
    }

    /**
     * Tap return given object or if that is null then app instance. This aids for chaining.
     *
     * @noinspection PhpMissingReturnTypeInspection
     */
    public function tap(?object $object = null)
    {
        return $object ?? $this->console;
    }

    /**
     * Performs user interaction if required to set some missing values.
     */
    public function interact(Interactor $io): void
    {
        // Subclasses will do what is necessary.
    }

    /**
     * Get or set command action.
     *
     * @param callable|null $action If provided it is set
     *
     * @return callable|self If $action provided then self, otherwise the preset action.
     */
    public function action(?callable $action = null): callable|self
    {
        if (func_num_args() === 0) {
            return $this->action;
        }

        $this->action = $action instanceof Closure ? Closure::bind($action, $this) : $action;

        return $this;
    }

    /**
     * Get a writer instance.
     */
    protected function getWriter(): Writer
    {
        return $this->console ? $this->console->getIo()->getWriter() : new Writer;
    }

    /**
     * Get IO instance.
     */
    protected function getIo(): Interactor
    {
        return $this->console ? $this->console->getIo() : new Interactor;
    }

    /**
     * Get ProgressBar instance.
     */
    protected function getProgress(?int $total = null): ProgressBar
    {
        return new ProgressBar($total, $this->getWriter());
    }
}
