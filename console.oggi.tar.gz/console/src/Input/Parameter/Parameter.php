<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Input\Parameter;

use Omega\Console\Trait\InflectorTrait;

use function json_encode;
use function ltrim;
use function sprintf;
use function str_contains;

/**
 * CLI parameter representation.
 *
 * Defines a structured representation of command-line parameters,
 * supporting various attributes such as required, optional, and variadic parameters.
 * It also includes filtering capabilities for sanitization or validation.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Input\Parameter
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
abstract class Parameter
{
    use InflectorTrait;

    /** @var string The parameter name. */
    protected string $name;

    /** @var bool Indicates whether the parameter is required. */
    protected bool $required = false;

    /** @var bool Indicates whether the parameter is optional. */
    protected bool $optional = false;

    /** @var bool Indicates whether the parameter is variadic (accepts multiple values). */
    protected bool $variadic = false;

    /** @var mixed Filter, sanitizer, or validator for the parameter. Can be any type, including callable
     *             functions, filters, or validation rules.
     * @noinspection PhpMissingFieldTypeInspection
     */
    protected $filter = null;


    /**
     * Constructor.
     *
     * @param string $raw     Holds the raw parameter definition.
     * @param string $desc    Holds the parameter description.
     * @param mixed  $default Holds the default value.
     * @param mixed  $filter  Holds a filter, sanitizer, or validate
     * @return void
     * @noinspection PhpMissingParamTypeInspection
     */
    public function __construct(
        protected string $raw,
        protected string $desc = '',
        protected $default = null,
        $filter = null
    ) {
        $this->filter   = $filter;
        $this->required = str_contains($raw, '<');
        $this->optional = str_contains($raw, '[');
        $this->variadic = str_contains($raw, '...');

        $this->parse($raw);
    }

    /**
     * Retrieves the raw parameter definition.
     *
     * @return string Return the raw parameter definition.
     */
    public function getRaw(): string
    {
        return $this->raw;
    }

    /**
     * Retrieves the parameter name.
     *
     * @return string Return the parameter name.
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Retrieves the parameter description.
     *
     * @param bool $withDefault Whether to include the default value in the description.
     * @return string Return the parameter description.
     */
    public function getDesc(bool $withDefault = false): string
    {
        if (!$withDefault || null === $this->default || '' === $this->default) {
            return $this->desc;
        }

        return ltrim(sprintf('%1$s [default: %2$s]', $this->desc, json_encode($this->default)));
    }

    /**
     * Retrieves the normalized attribute name in camel case.
     *
     * @return string Return the normalized attribute name.
     */
    public function getAttributeName(): string
    {
        return $this->toCamelCase($this->name);
    }

    /**
     * Checks whether the parameter is required.
     *
     * @return bool Return true if required, false otherwise.
     */
    public function isRequired(): bool
    {
        return $this->required;
    }

    /**
     * Checks whether the parameter is optional.
     *
     * @return bool Return true if optional, false otherwise.
     */
    public function isOptional(): bool
    {
        return $this->optional;
    }

    /**
     * Checks whether the parameter is variadic (accepts multiple values).
     *
     * @return bool Return true if variadic, false otherwise.
     */
    public function isVariadic(): bool
    {
        return $this->variadic;
    }

    /**
     * Retrieves the default value of the parameter.
     *
     * @return mixed Return the default value.
     */
    public function getDefault(): mixed
    {
        if ($this->isVariadic()) {
            return (array) $this->default;
        }

        return $this->default;
    }

    /**
     * Applies the filter/sanitizer/validator callback to a value.
     *
     * @param mixed $raw Holds the raw input value.
     * @return mixed Return the processed value after applying the filter.
     */
    public function filter(mixed $raw): mixed
    {
        if ($this->filter) {
            $callback = $this->filter;

            return $callback($raw);
        }

        return $raw;
    }

    /**
     * Parses the raw parameter definition.
     *
     * @param string $raw Holds the raw parameter definition.
     * @return void
     */
    abstract protected function parse(string $raw): void;
}
