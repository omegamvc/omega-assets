<?php

/**
 * Part of Omega - Console Package
 * PHP version 8.3
 *
 * This interface defines a contract for objects that can be grouped.
 * It allows setting and retrieving a group identifier.
 *
 * @link      https://omegamvc.github.io
 * @author    Adriano Giovannini <agisoftt@gmail.com>
 * @copyright Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license   https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version   1.0.0
 */

declare(strict_types=1);

namespace Omega\Console\Input;

use Omega\Console\Input\Parameter\Parameter;

use function explode;
use function is_array;
use function str_contains;
use function str_replace;

/**
 * This class handles the parsing and storage of command-line arguments,
 * allowing them to have default values and supporting variadic arguments.
 *
 * @category   Omega
 * @package    Console
 * @subpackage Input
 * @link       https://omegamvc.github.io
 * @author     Adriano Giovannini <agisoftt@gmail.com>
 * @copyright  Copyright (c) 2024 - 2025 Adriano Giovannini (https://omegamvc.github.io)
 * @license    https://www.gnu.org/licenses/gpl-3.0-standalone.html GPL V3.0+
 * @version    1.0.0
 */
class Argument extends Parameter
{
    /**
     * {@inheritdoc}
     */
    protected function parse(string $raw): void
    {
        $this->name = $name = str_replace(['<', '>', '[', ']', '.'], '', $raw);

        // Format is "name:default+value1,default+value2" ('+' => ' ')!
        if (str_contains($name, ':')) {
            $name                         = str_replace('+', ' ', $name);
            [$this->name, $this->default] = explode(':', $name, 2);
        }

        $this->prepDefault();
    }

    /**
     * Prepares the default value for variadic arguments.
     *
     * If the argument is variadic and has a default value,
     * but the default is not an array, it is converted into one.
     *
     * @return void
     */
    protected function prepDefault(): void
    {
        if ($this->variadic && $this->default && !is_array($this->default)) {
            $this->default = explode(',', $this->default, 2);
        }
    }
}
