<?php

declare(strict_types=1);

namespace Omega\Console\Test\Input;

use Omega\Console\Console;
use Omega\Console\Input\Command;
use Omega\Console\Output\ProgressBar;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use RuntimeException;

use function debug_backtrace;

class CommandTest extends TestCase
{
    public function test_new()
    {
        $p = $this->newCommand('0.0.' . rand(1, 10));

        $data = $this->data();
        foreach ($data['options'] as $option) {
            $p->setOption($option['cmd']);
        }

        foreach ($data['argvs'] as $argv) {
            if (isset($argv['throws'])) {
                $this->expectException($argv['throws'][0]);
                $this->expectExceptionMessage($argv['throws'][1]);
            }

            $values = $p->parse($argv['argv']);

            $argv += ['expect' => []];

            foreach ($argv['expect'] as $key => $expect) {
                $this->assertSame($expect, $values[$key]);
            }
        }
    }

    public function data()
    {
        return require __DIR__ . '/fixture.php';
    }

    public function test_arguments()
    {
        $p = $this->newCommand()->setArguments('<cmd> [env]')->parse(['php', 'mycmd']);

        $this->assertSame('mycmd', $p->cmd);
        $this->assertNull($p->env, 'No default');

        $p = $this->newCommand()->setArguments('<id:adhocore> [hobbies...]')->parse(['php']);

        $this->assertSame('adhocore', $p->id, 'Default');
        $this->assertEmpty($p->hobbies, 'No default');
        $this->assertSame([], $p->hobbies, 'Variadic');

        $p = $this->newCommand()->setArguments('<dir> [dirs...]')->parse(['php', 'dir1', 'dir2', 'dir3']);
        $this->assertSame('dir1', $p->dir);
        $this->assertTrue(is_array($p->dirs));
        $this->assertSame(['dir2', 'dir3'], $p->dirs);
    }

    public function test_arguments_variadic_not_last()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Only last argument can be variadic');

        $p = $this->newCommand()->setArguments('[paths...]')->setArgument('[env]', 'Env');
    }

    public function test_arguments_with_options()
    {
        $p = $this->newCommand()->setArguments('<cmd> [env]')
            ->setOption('-c --config', 'Config')
            ->setOption('-d --dir', 'Dir')
            ->parse(['php', 'thecmd', '-d', 'dir1', 'dev', '-c', 'conf.yml', 'any', 'thing']);

        $this->assertArrayHasKey('help', $p->getValues());
        $this->assertArrayNotHasKey('help', $p->getValues(false));

        $this->assertSame('dir1', $p->dir);
        $this->assertSame('conf.yml', $p->config);
        $this->assertSame('thecmd', $p->cmd);
        $this->assertSame('dev', $p->env);
        $this->assertSame('any', $p->{0});
        $this->assertSame('thing', $p->{1});
    }

    public function test_options_repeat()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('The parameter "--apple" is already registered');

        $p = $this->newCommand()->setOption('-a --apple', 'Apple')->setOption('-a --apple', 'Apple');
    }

    public function test_options_unknown()
    {
        $p = $this->newCommand('', '', true)->parse(['php', '--hot-path', '/path']);
        $this->assertSame('/path', $p->hotPath, 'Allow unknown');

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('Option "--random" not registered');

        // Dont allow unknown
        $p = $this->newCommand()->setOption('-k known [opt]')->parse(['php', '-k', '--random', 'rr']);
    }

    public function test_literals()
    {
        $p = $this->newCommand()->setOption('-a --apple', 'Apple')->setOption('-b --ball', 'Ball');

        $p->parse(['php', '-a', 'the apple', '--', '--ball', 'the ball']);

        $this->assertSame('the apple', $p->apple);
        $this->assertNotSame('the ball', $p->ball);
        $this->assertSame('--ball', $p->{0}, 'Should be arg');
        $this->assertSame('the ball', $p->{1}, 'Should be arg');
    }

    public function test_options()
    {
        $p = $this->newCommand()->setOption('-u --user-id [id]', 'User id')->parse(['php']);
        $this->assertNull($p->userId, 'Optional no default');

        $p = $this->newCommand()->setOption('-c --cheese [type]', 'User id')->parse(['php', '-c']);
        $this->assertSame(true, $p->cheese, 'Optional given');

        $p = $this->newCommand()->setOption('-u --user-id [id]', 'User id', null, 1)->parse(['php']);
        $this->assertSame(1, $p->userId, 'Optional default');

        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('Option "--user-id" is required');

        $p = $this->newCommand()->setOption('-u --user-id <id>', 'User id')->parse(['php']);
    }

    public function test_special_options()
    {
        $p = $this->newCommand()->setOption('-n --no-more', '')->setOption('-w --with-that', '');

        $p->parse(['php', '-nw']);

        $this->assertTrue($p->that, '--with becomes true when given');
        $this->assertFalse($p->more, '--no becomes false when given');

        $p = $this->newCommand()->setOption('--any')->parse(['php', '--any=thing']);
        $this->assertSame('thing', $p->any);

        $p = $this->newCommand()->setOption('-m --many [item...]')->parse(['php', '--many=1', '2']);
        $this->assertSame(['1', '2'], $p->many);
    }

    public function test_bool_options()
    {
        $p = $this->newCommand()->setOption('-n --no-more', '')->setOption('-w --with-that', '')
            ->parse(['php']);

        $this->assertTrue($p->more);
        $this->assertFalse($p->that);

        $p = $this->newCommand()->setOption('-n --no-more', '')->setOption('-w --with-that', '')
            ->parse(['php', '--no-more', '-w']);

        $this->assertFalse($p->more);
        $this->assertTrue($p->that);
    }

    public function test_user_options()
    {
        $p = $this->newCommand();

        $this->assertEmpty($p->getOptions());

        $p = $this->newCommand()->setOption('-u --user', 'User');

        $this->assertNotEmpty($o = $p->getOptions());
        $this->assertCount(1, $o);
        $this->assertSame('user', reset($o)->getName());
    }

    public function test_complex_value_option()
    {
        $p = $this->newCommand()
            ->setOption('-l --limit', 'limit', 'intval')
            ->setOption('-o --order-by', 'order by');

        // `--order-by="id desc"` in terminal becomes `--order-by=id desc` in PHP.
        $v = $p->parse(['cmd', '-l=5', '--order-by=id desc'])->getValues();

        $this->assertArrayHasKey('limit', $v);
        $this->assertArrayHasKey('orderBy', $v);
        $this->assertSame(5, $v['limit']);
        $this->assertSame('id desc', $v['orderBy']);
    }

    public function test_usage()
    {
        $p = $this->newCommand()->usage('Usage: $ cmd [...]');

        $this->assertSame('Usage: $ cmd [...]', $p->usage());
    }

    public function test_event()
    {
        $p = $this->newCommand()->setOption('--hello')->on(function () {
            echo 'hello event';
        });

        ob_start();
        $p->parse(['php', '--hello']);

        $this->assertSame('hello event', ob_get_clean());
    }

    public function test_no_value()
    {
        $p = $this->newCommand()->setOption('-x --xyz')->parse(['php', '-x']);

        $this->assertTrue($p->xyz, 'not required becomes true');
    }

    public function test_args()
    {
        $p = $this->newCommand()->setArguments('<a> [b]')->setOption('-x --xyz')
            ->parse(['php', 'A', '-x', 'X', 'B', 'C', 'D']);

        $this->assertSame(['a' => 'A', 'b' => 'B', 'C', 'D'], $p->getArgs());
    }

    public function test_tap()
    {
        $this->assertInstanceOf(static::class, $this->newCommand()->tap($this));
    }

    public function test_console_tap()
    {
        $c = $this->newCommand();
        $this->assertNull($c->tap());
        $this->assertNull($c->getConsole());

        $c = $this->newCommand('', '', false, new Console('app'));
        $this->assertInstanceOf(Console::class, $c->getConsole());
        $this->assertInstanceOf(Console::class, $c->getConsole());
    }

    public function test_bind()
    {
        $c = $this->newCommand()->bind(new Console('getConsole'));
        $this->assertInstanceOf(Console::class, $c->getConsole());

        $c = $this->newCommand()->bind(null);
        $this->assertNull($c->getConsole());
    }

    public function test_unset()
    {
        $c = $this->newCommand();
        $this->assertCount(3, $c->getAllOptions());
        $this->assertArrayHasKey('verbosity', $c->getAllOptions());
        $c->unset('verbosity');
        $this->assertCount(2, $c->getAllOptions());
        $this->assertArrayNotHasKey('verbosity', $c->getAllOptions());
    }

    public function test_progress()
    {
        new class($this) extends Command {
            public function __construct($tester)
            {
                $this->console = null;
                $tester->assertInstanceOf(ProgressBar::class, $this->getProgress(10));
            }
        };
    }

    public function test_custom_help()
    {
        $p = $this->newCommand();
        $p->setHelp('This should be my custom help screen');
        $this->assertStringContainsString('This should be my custom help screen', $p->setHelp());
    }

    protected function newCommand(string $version = '0.0.1', string $desc = '', bool $allowUnknown = false, $app = null)
    {
        $p = new Command('cmd', $desc, $allowUnknown, $app);

        return $p->setVersion($version . debug_backtrace()[1]['function'])->onExit(function () {
            return false;
        });
    }
}
