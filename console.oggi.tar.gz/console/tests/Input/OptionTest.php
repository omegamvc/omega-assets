<?php

declare(strict_types=1);

namespace Omega\Console\Test\Input;

use Omega\Console\Input\Option;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class OptionTest extends TestCase
{
    #[DataProvider('data')]
    public function testNew($cmd, $expect)
    {
        $o = new Option($cmd);

        $more = [];
        if (isset($expect['default'])) {
            $more += ['default' => $o->getDefault()];
        }
        if (isset($expect['bool'])) {
            $more += ['bool' => $o->isBoolean()];
        }

        $this->assertEquals($cmd, $o->getRaw());

        $this->assertEquals($expect, [
                'long'     => $o->getLongName(),
                'short'    => $o->getShortName(),
                'required' => $o->isRequired(),
                'variadic' => $o->isVariadic(),
                'name'     => $o->getName(),
                'aname'    => $o->getAttributeName(),
            ] + $more);
    }

    public function testIs()
    {
        $o = new Option('-a --age');

        $this->assertTrue($o->isMatches('-a'));
        $this->assertTrue($o->isMatches('--age'));

        $this->assertFalse($o->isMatches('--rage'));
        $this->assertFalse($o->isMatches('--k'));
        $this->assertFalse($o->isMatches('a'));
        $this->assertFalse($o->isMatches('age'));
    }

    public function testFilter()
    {
        $o = new Option('-a --age', 'Age', 18, 'intval');

        $this->assertSame(18, $o->getDefault());
        $this->assertSame(10, $o->filter('10'));

        $in = 'apple';
        $o  = new Option('-f, --fruit', 'Age', 'orange', 'strtoupper');

        $this->assertNotSame($o->filter($in), $in);
        $this->assertSame('APPLE', $o->filter($in));

        $this->assertSame('orange', $o->getDefault(), 'default shouldnt be filtered');

        $o                   = new Option('--long-only');
        $this->assertSame($r = rand(), $o->filter($r));
    }

    public static function data(): array
    {
        $f = require __DIR__ . '/fixture.php';

        return array_map(fn($item) => [$item['cmd'], $item['expect']], $f['options']);
    }
}
