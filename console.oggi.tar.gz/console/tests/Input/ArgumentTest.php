<?php

declare(strict_types=1);

namespace Omega\Console\Test\Input;

use Omega\Console\Input\Argument;
use PHPUnit\Framework\TestCase;

class ArgumentTest extends TestCase
{
    public function test()
    {
        $a = new Argument('<a>');
        $this->assertTrue($a->isRequired());
        $this->assertFalse($a->isOptional());

        $a = new Argument('[b:ball]');
        $this->assertFalse($a->isRequired());
        $this->assertSame('ball', $a->getDefault());

        $a = new Argument('[thing:a+b,c+d...]');
        $this->assertSame('thing', $a->getName());
        $this->assertTrue($a->isVariadic());
        $this->assertSame(['a b', 'c d'], $a->getDefault());
    }
}
