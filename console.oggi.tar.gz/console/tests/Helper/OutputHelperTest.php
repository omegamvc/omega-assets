<?php

declare(strict_types=1);

namespace Omega\Console\Test\Helper;

use Omega\Console\Helper\OutputHelper;
use Omega\Console\Input\Argument;
use Omega\Console\Input\Command;
use Omega\Console\Input\Option;
use Omega\Console\Output\Color;
use Omega\Console\Output\Writer;
use DateTime;
use PHPUnit\Framework\TestCase;

use function file;
use function implode;
use function str_replace;

use const FILE_IGNORE_NEW_LINES;

class OutputHelperTest extends TestCase
{
    protected static $ou = __DIR__ . '/output';

    public function setUp(): void
    {
        file_put_contents(static::$ou, '', LOCK_EX);
    }

    public static function tearDownAfterClass(): void
    {
        // Make sure we clean up after ourselves:
        if (file_exists(static::$ou)) {
            unlink(static::$ou);
        }
    }

    public function test_show_arguments()
    {
        $this->newHelper()->showArgumentsHelp([
            new Argument('<path>', 'The path'),
            new Argument('[config:defaultConfig]'),
        ], 'Arg Header', 'Arg Footer');

        $this->assertSame([
            'Arg Header',
            '',
            'Arguments:',
            '  <path>      The path',
            '  [config]    [default: "defaultConfig"]',
            '',
            'Arg Footer',
        ], $this->outputs());
    }

    public function test_show_options()
    {
        $this->newHelper()->showOptionsHelp([
            new Option('-h --help', 'Show help'),
            new Option('-n|--full-name <name>', 'Full name', 'John'),
        ], 'Opt Header', 'Opt Footer');

        $this->assertSame([
            'Opt Header',
            '',
            'Options:',
            '  <-n|--full-name>    Full name [default: "John"]',
            '  [-h|--help]         Show help',
            '',
            'Opt Footer',
        ], $this->outputs());
    }

    public function test_show_commands()
    {
        $this->newHelper()->showCommandsHelp([
            new Command('rm', 'Remove file or folder'),
            new Command('mkdir', 'Make a folder'),
            new Command('group:rm', 'Remove file or folder'),
            new Command('group:mkdir', 'Make a folder'),
        ], 'Cmd Header', 'Cmd Footer');

        $this->assertSame([
            'Cmd Header',
            '',
            'Commands:',
            'group',
            '  group:mkdir    Make a folder',
            '  group:rm       Remove file or folder',
            '*',
            '  mkdir          Make a folder',
            '  rm             Remove file or folder',
            '',
            'Cmd Footer',
        ], $this->outputs());
    }

    public function test_empty()
    {
        $this->newHelper()->showCommandsHelp([], 'Header');

        $this->assertSame([
            'Header',
            '',
            'Commands:',
            '  (n/a)',
        ], $this->outputs());
    }

    public function test_show_usage()
    {
        $argv0 = $_SERVER['argv'][0];

        $_SERVER['argv'][0] = 'test';

        $this->newHelper()->showUsage(implode('', [
            '<bold>  $0</end> <comment>-a apple</end> ## apple only<eol>',
            '<bold>  $0</end> <comment>-a apple -b ball</end> ## apple ball<eol>',
            'loooooooooooong text ## something<eol>',
            'no shell comments<eol>',
            'short text ## something else<eol>',
        ]));

        $this->assertEquals([
            '',
            'Usage Examples:',
            '  test -a apple          # apple only',
            '  test -a apple -b ball  # apple ball',
            'loooooooooooong text     # something',
            'no shell comments',
            'short text               # something else',
            '',
        ], $this->outputs());

        $_SERVER['argv'][0] = $argv0;
    }

    public function test_stringify()
    {
        $str = $this->newHelper()->stringifyArgs([[null, 'string', 10000, 12.345, new DateTime]]);

        $this->assertSame("[NULL, 'string', 10000, 12.345, DateTime]", $str);
    }

    public function newHelper()
    {
        return new OutputHelper(new Writer(static::$ou, new class extends Color {
            protected string $format = ':txt:';
        }));
    }

    protected function outputs(): array
    {
        return str_replace("\033[0m", '', file(static::$ou, FILE_IGNORE_NEW_LINES));
    }
}
