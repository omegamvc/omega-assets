<?php

declare(strict_types=1);

namespace Omega\Console\Test;

use Omega\Console\Console;
use Omega\Console\Input\Command;
use Omega\Console\InputOutput\Interactor;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;
use Throwable;

class ConsoleTest extends TestCase
{
    protected static string $in = __DIR__ . '/input.test';
    protected static string $ou = __DIR__ . '/output.test';
    private bool $actionCalled;

    public function setUp(): void
    {
        file_put_contents(static::$in, '', LOCK_EX);
        file_put_contents(static::$ou, '', LOCK_EX);
    }

    public function tearDown(): void
    {
        // Make sure we clean up after ourselves:
        if (file_exists(static::$in)) {
            unlink(static::$in);
        }
        if (file_exists(static::$ou)) {
            unlink(static::$ou);
        }
    }

    public function testNew()
    {
        $a = $this->newApp('project', '1.0.1');

        $this->assertInstanceOf(Command::class, $c = $a->getCommandFor([]));
        $this->assertSame('__default__', $c->getName());
        $this->assertSame('Default command', $c->getDesc());

        $this->assertSame('project', $a->getName());
        $this->assertSame('1.0.1', $a->getVersion());
    }

    public function testCommands()
    {
        $a = $this->newApp('project', '1.0.1');
        $this->assertEmpty($a->getCommands());

        $a->setCommand('new', 'Create new project', 'n');
        $this->assertNotEmpty($a->getCommands());
        $this->assertCount(1, $a->getCommands());

        $this->assertSame('new', $a->getCommandFor(['project', 'new'])->getName());
        $this->assertSame('new', $a->getCommandFor(['project', 'n'])->getName());
        $this->assertSame('__default__', $a->getCommandFor(['project', 'nn'])->getName());
    }

    public function testGroups()
    {
        $a = $this->newApp('project', '1.0.0');

        $a->setGroup('Configuration', function ($a) {
            $a->setCommand('config:set');
            $a->setCommand('config:get');
            $a->setCommand('config:del');
        });

        $ct = 0;
        foreach ($a->getCommands() as $cmd) {
            if (in_array($cmd->getName(), ['config:set', 'config:get', 'config:del'], true)) {
                $ct++;
                $this->assertSame('Configuration', $cmd->getGroup());
            }
        }

        $this->assertSame(3, $ct);
    }

    public function testCommandDupName()
    {
        $a = $this->newApp('project', '1.0.1');

        $a->setCommand('clean', 'Cleanup project status');

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Command "clean" already added');
        $a->setCommand('clean', 'Cleanup project status', 'c');
    }

    public function testCommandDupAlias()
    {
        $a = $this->newApp('project', '1.0.1');

        $a->setCommand('clean', 'Cleanup project status', 'c');

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Command "c" already added');
        $a->setCommand('c', 'Cleanup project status', 'd');
    }

    public function testParse()
    {
        $a = $this->newApp('git');

        $a->setCommand('add', 'stage change', 'a')->setArguments('<files...>');
        $c = $a->parse(['git', 'add', 'file1', 'file2']);

        $this->assertSame(['file1', 'file2'], $c->files);
        $this->assertSame(['git', 'add', 'file1', 'file2'], $a->getArgv());
    }

    public function testHelp()
    {
        $logo = '
               _ _
          __ _(_) |_
         / _` | | __|
        | (_| | | |_
         \__, |_|\__|
         |___/
        ';

        $this->newApp('git', '0.0.2')
            ->setLogo($logo)
            ->setCommand('add', 'stage change', 'a')
                ->setArguments('<files...>')
                ->tap()
            ->parse(['git', '--help']);

        $out = file_get_contents(static::$ou);

        $this->assertStringContainsString('git, version 0.0.2', $out);
        $this->assertStringContainsString($logo, $out);
        $this->assertStringContainsString('add', $out);
        $this->assertStringContainsString('stage change', $out);
    }

    public function testCustomHelp()
    {
        $this->newApp('git', '0.0.2')
          ->help('This should be my custom help screen')
          ->parse(['git', '--help']);

        $out = file_get_contents(static::$ou);

        $this->assertStringContainsString('This should be my custom help screen', $out);
    }

    public function testAction()
    {
        ($a = $this->newApp('git', '0.0.2'))
            ->setCommand('add', 'stage change', 'a')
                ->setArguments('<files...>')
                ->action(function ($files) {
                    echo 'Add ' . implode(' and ', $files);
                })
                ->tap($a)
            ->setCommand('config', 'list config', 'c')
                ->setOption('-l --list <scope>', 'list config')
                ->action(function ($list) {
                    echo "Config $list: user.email=user+100@gmail.com";
                });

        ob_start();
        $a->handle(['git', 'add', 'a.php', 'b.php']);
        $buffer = ob_get_clean();
        $this->assertSame('Add a.php and b.php', $buffer);

        ob_start();
        $a->handle(['git', 'c', '--list', 'global']);
        $buffer = ob_get_clean();
        $this->assertSame('Config global: user.email=user+100@gmail.com', $buffer);
    }

    public function testNoAction()
    {
        $a = $this->newApp('git', '0.0.2');

        $a->setCommand('add', 'stage change', 'a')->setArguments('<files...>');

        $this->assertFalse($a->handle(['git', 'add', 'a.php', 'b.php']));
    }

    public function testActionException()
    {
        $a = $this->newApp('git', '0.0.2');

        $a->setCommand('add', 'stage change', 'a')->setArguments('<files...>')->action(function () {
            throw new InvalidArgumentException('Dummy InvalidArgumentException');
        });

        $a->handle(['git', 'add', 'a.php', 'b.php']);

        $this->assertStringContainsString('Dummy InvalidArgumentException', file_get_contents(static::$ou));
    }

    public function testArrayAction()
    {
        $a = $this->newApp('git', '0.0.2');

        $this->actionCalled = false;

        $a->setCommand('add', 'stage change', 'a')->setArguments('<files...>')->action([$this, 'action']);
        $a->handle(['git', 'add', 'a.php', 'b.php']);

        $this->assertTrue($this->actionCalled);
    }

    public function action(): void
    {
        $this->actionCalled = true;
    }

    public function testLogo()
    {
        $a = $this->newApp('test', '0.0.2');

        $this->assertSame($a, $a->setLogo($logo = '
            | |_ ___  ___| |_
            | __/ _ \/ __| __|
            | ||  __/\__ \ |_
             \__\___||___/\__|
        '));

        $this->assertSame($logo, $a->setLogo());
    }

    public function testLogoCommand()
    {
        $a = $this->newApp('test', '0.0.2');
        $c = $a->setCommand('cmd');

        $this->assertSame($c, $c->setLogo($logo = '
            | |_ ___  ___| |_
            | __/ _ \/ __| __|
            | ||  __/\__ \ |_
             \__\___||___/\__|
        '));

        $this->assertSame($logo, $c->setLogo());
    }

    public function testAdd()
    {
        $a = $this->newApp('test', '0.0.1-test');

        $this->assertSame($a, $a->addCommand(new Command('cmd'), 'c', true));
        $this->assertSame('cmd', $a->getCommandFor(['test', 'cmd'])->getName());
    }

    public function testAddDup()
    {
        $a = $this->newApp('test', '0.0.1-test');

        $this->expectException(InvalidArgumentException::class);

        $a->addCommand(new Command('cmd'), 'cm');
        $a->addCommand(new Command('cm'));
    }

    public function testIo()
    {
        $a = $this->newApp('test', '0.0.1-test');

        $this->assertInstanceOf(Interactor::class, $oio = $a->getIo());

        $a->getIo(new Interactor);

        $this->assertInstanceOf(Interactor::class, $a->getIo());
        $this->assertNotSame($oio, $a->getIo());
    }

    public function testHandleEmpty()
    {
        $a = $this->newApp('test', '0.0.1-test');

        $a->setCommand('make', 'Make tests');
        $a->handle(['test']);

        $o = file_get_contents(static::$ou);

        $this->assertStringContainsString('test, version 0.0.1-test', $o);
        $this->assertStringContainsString('Commands:', $o);
        $this->assertStringContainsString('make', $o);
        $this->assertStringContainsString('Make tests', $o);
    }

    public function test_cmd_not_found()
    {
        $a = $this->newApp('test')->addCommand(new Command('cmd'))->handle(['test', 'cm']);
        $o = file_get_contents(static::$ou);

        $this->assertStringContainsString('Command cm not found', $o);
        $this->assertStringContainsString('Did you mean cmd?', $o);
    }

    public function test_io_returns_new_instance_if_not_provided(): void
    {
        $app = new Console('some-name', '0.0.1', fn () => false);

        $this->assertInstanceOf(
            Interactor::class,
            $app->getIo()
        );
    }

    public function test_on_exception()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage($msg = 'this will be rethrown and propagated');

        $cmd = (new Command('cmd'))->action(fn () => throw new InvalidArgumentException($msg));
        $app = $this->newApp('test')->addCommand($cmd)->onException(fn (Throwable $e) => throw $e);
        $app->handle(['test', 'cmd']);
    }

    protected function newApp(string $name, string $version = ''): Interactor|null|Console
    {
        $app = new Console($name, $version ?: '0.0.1', fn () => false);

        return $app->getIo(new Interactor(static::$in, static::$ou));
    }

    public function testDefaultCommand()
    {
        $app = $this->newApp('test');

        // Add some sample commands to the application
        $app->setCommand('command1')->action(function () {
            echo 'This should be the default command';
        });
        $app->setCommand('command2');

        // Test setting a valid default command
        $app->defaultCommand('command1');
        $this->assertEquals('command1', $app->getDefaultCommand());

        // Test executing a default command
        ob_start();
        $app->handle(['test']);
        $buffer = ob_get_clean();
        $this->assertSame('This should be the default command', $buffer);

        // Test setting an invalid default command
        $this->expectException(InvalidArgumentException::class);
        $app->defaultCommand('invalid_command');
    }
}
