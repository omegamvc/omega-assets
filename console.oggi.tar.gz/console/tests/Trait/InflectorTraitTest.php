<?php

declare(strict_types=1);

namespace Omega\Console\Test\Trait;

use Omega\Console\Trait\InflectorTrait;
use PHPUnit\Framework\TestCase;

class InflectorTraitTest extends TestCase
{
    use InflectorTrait;

    public function testToCamelCase()
    {
        $this->assertSame('aB', $this->toCamelCase('a-b'));
        $this->assertSame('theLongName', $this->toCamelCase('--the_long-name'));
        $this->assertSame('aBC', $this->toCamelCase('a_bC'));
    }

    public function testToWords()
    {
        $this->assertSame('A B', $this->toWords('a-b'));
        $this->assertSame('The Long Name', $this->toWords('--the_long-name'));
        $this->assertSame('A BC', $this->toWords('a_bC'));
    }

    public function testStrwidth()
    {
        $this->assertSame(5, $this->strWidth('Hello'));
        $this->assertSame(0, $this->strWidth(''));

        $this->assertSame(5, strlen('Hello'));
        $this->assertSame(0, strlen(''));
    }

    public function testSubstr()
    {
        $this->assertSame('ello', $this->substr('Hello', 1, 4));
        $this->assertSame('', $this->substr('Hello', 1, 0));
    }
}
