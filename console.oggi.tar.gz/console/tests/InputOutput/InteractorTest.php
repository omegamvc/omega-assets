<?php

namespace Omega\Console\Test\InputOutput;

use Omega\Console\Input\Reader;
use Omega\Console\InputOutput\Interactor;
use Omega\Console\Output\Writer;
use PHPUnit\Framework\MockObject\Exception;
use PHPUnit\Framework\TestCase;

class InteractorTest extends TestCase
{
    private $readerMock;
    private $writerMock;
    private $interactor;

    /**
     * @throws Exception
     */
    protected function setUp(): void
    {
        $this->readerMock = $this->createMock(Reader::class);
        $this->writerMock = $this->createMock(Writer::class);

        // Creiamo un'interactor con i mock$this->interactor = new Interactor();
        $this->interactor = new class($this->readerMock, $this->writerMock) extends Interactor {
            public function __construct($reader, $writer)
            {
                $this->reader = $reader;
                $this->writer = $writer;
            }
        };
    }

    public function testConfirmYes()
    {
        // Simula input dell'utente: 'y'
        $this->readerMock
            ->method('read')
            ->willReturn('y');

        // Verifica che confirm() restituisca true
        $this->assertTrue($this->interactor->confirm('Are you sure?'));
    }

    public function testConfirmNo()
    {
        // Simula input dell'utente: 'n'
        $this->readerMock
            ->method('read')
            ->willReturn('n');

        // Verifica che confirm() restituisca false
        $this->assertFalse($this->interactor->confirm('Are you sure?'));
    }

    public function testPrompt()
    {
        $this->readerMock
            ->method('read')
            ->willReturn('my input');

        $this->assertEquals('my input', $this->interactor->prompt('Enter something:'));
    }

    public function testPromptWithDefault()
    {
        $this->readerMock
            ->method('read')
            ->willReturn('');

        $this->assertEquals('default', $this->interactor->prompt('Enter something:', 'default'));
    }

    public function testPromptHidden()
    {
        $this->readerMock
            ->method('readHidden')
            ->willReturn('secret');

        $this->assertEquals('secret', $this->interactor->promptHidden('Enter password:'));
    }
}
